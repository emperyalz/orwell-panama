# @quexopa/multiplayer-workshop

Drop-in multiplayer workshop layer for **React + Convex** apps. Sticky notes, version snapshots, presence dots, hand-off-to-Claude prompt, locked client-only builds — wired up in one command.

A standalone, project-agnostic tool. Drop it into any React + Convex app and you get a complete collaborative-workshop surface — no host-specific assumptions in the package. Each consumer project keeps its own deployment; the package keeps moving forward and every consumer pulls updates on their own cadence.

---

## What it gives you

- **Sticky notes** — drop them anywhere on any page, attach images + screenshots, optional aimed arrows, group-sync duplicates across pages
- **Version navigator** — fork a session into v2, v3, etc. snapshots; resolved notes don't carry over
- **Live presence** — see who's editing what field in real-time, with colored avatar dots
- **Hand-off button** — one-click copies a "Pull from Convex deployment X session Y" prompt for Claude
- **Locked client builds** — generate a separate Vercel deployment with **zero** workshop chrome that the client can't trim or manipulate
- **Identity modal** — name + color picker, persisted per browser
- **Action items + decisions log** — for tracking what the workshop produces
- **Inline comments** — attach to any field path
- **Storyboard module (opt-in, v0.3+)** — flipbook-style AI storyboarding with style bible, drag-reorder slides, vision auto-captions, and templated prompt export for Runway / Sora / Veo / Kling / Seedance / Higgsfield
- **Convex backend** — schema fragment + function files, all generic and reusable

## Install

### Option A — with Claude Code (recommended)

```
/plugin marketplace add emperyalz/multiplayer-workshop-plugin
/multiplayer:install
```

Claude installs the package, copies the Convex functions, edits your `App.tsx` to mount the provider, adds the CSS import, and tells you what to do next.

### Option B — without Claude Code

```bash
npm install git+ssh://git@github.com/emperyalz/multiplayer-workshop.git#main
npx multiplayer-workshop init
```

The CLI does the same orchestration — interactively asks you for project root, Convex deployment name, brand colors, etc.

### Option C — manual

```bash
npm install git+ssh://git@github.com/emperyalz/multiplayer-workshop.git#main
```

Then in your `convex/schema.ts`:

```ts
import { defineSchema } from 'convex/server';
import { multiplayerTables } from '@quexopa/multiplayer-workshop/convex-templates/multiplayerSchema';

export default defineSchema({
  ...multiplayerTables,
  // ...your own tables
});
```

Copy the function files from `node_modules/@quexopa/multiplayer-workshop/src/convex/templates/` into your `convex/` directory.

In your `main.tsx`:

```tsx
import { ConvexProvider, ConvexReactClient } from 'convex/react';
import { MultiplayerProvider } from '@quexopa/multiplayer-workshop';
import { api } from './convex/_generated/api';
import '@quexopa/multiplayer-workshop/styles.css';

const convex = new ConvexReactClient(import.meta.env.VITE_CONVEX_URL);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <ConvexProvider client={convex}>
    <MultiplayerProvider
      api={api}
      config={{
        convexDeployment: 'your-convex-deployment-name',
        brand: { name: 'My Workshop', primaryColor: '#C8102E' },
      }}
    >
      <App />
    </MultiplayerProvider>
  </ConvexProvider>,
);
```

In your `App.tsx`:

```tsx
import {
  StickyNotesProvider,
  VersionNavigator,
  HandoffButton,
  NotesNavDropdown,
  IdentityModal,
  loadIdentity,
  getSessionId,
  usePresence,
} from '@quexopa/multiplayer-workshop';

// Top-level component:
const sessionId = getSessionId();
const identity = loadIdentity();
const { peers } = usePresence(sessionId, identity.editorId, identity.name, identity.color);

return (
  <>
    <YourTopBar>
      <NotesNavDropdown />
      <HandoffButton sessionId={sessionId} />
    </YourTopBar>

    <YourContent />

    <StickyNotesProvider sessionId={sessionId} identity={identity} />
    <VersionNavigator sessionId={sessionId} identity={identity} />
  </>
);
```

That's the whole integration.

---

## Storyboard module (opt-in, v0.3+)

Flipbook-style AI storyboarding tool with multiplayer collab. Drag-reorder slides (image or short video), per-slide camera/shot metadata, vision-auto-captioned references, and a "style bible" of typed entities (characters / environments / props / camera looks) that get prepended to every slide's prompt. Output is templated per video LLM — Runway, Sora, Veo, Kling, Seedance, Higgsfield, or model-agnostic.

### Install (opt-in)

```bash
npx multiplayer-workshop init --with-storyboards
```

Spread BOTH schema fragments in your `convex/schema.ts`:

```ts
import { defineSchema } from 'convex/server';
import { multiplayerTables } from './multiplayerSchema';
import { storyboardTables } from './storyboardSchema';

export default defineSchema({
  ...multiplayerTables,
  ...storyboardTables,
});
```

Mount the editor wherever you want:

```tsx
import { StoryboardEditor, StoryboardListView } from '@quexopa/multiplayer-workshop';

<StoryboardListView
  sessionId={sessionId}
  identity={identity}
  onOpen={(boardId) => navigate(`?board=${boardId}`)}
/>

// Or jump straight into a board:
<StoryboardEditor
  storyboardId={boardId}
  sessionId={sessionId}
  identity={identity}
  onClose={() => navigate(`/`)}
/>
```

### Vision auto-captioning (optional)

Set `GEMINI_API_KEY` on your Convex deployment and slide / reference / entity uploads automatically get captioned. If not set, captioning silently no-ops and the user fills captions manually:

```bash
npx convex env set GEMINI_API_KEY=<your-gemini-key>
```

### Customizing prompt templates

Templates live in `lib/promptTemplates.ts` as mustache-ish strings with named slots. Override per host by writing rows to the `promptTemplates` Convex table, or pass an `override` string to `renderPromptForModel(model, ctx, override)` directly.

---

## URL conventions

The package follows a 3-mode URL convention. You can adopt it or roll your own.

| URL | Mode | Purpose |
|---|---|---|
| `?session=xxx` | Workshop | Default — full multiplayer chrome, edit everything |
| `?present=true` | Present | Hide workshop panels (still has multiplayer for internal review) |
| `?session=xxx-v2` | Frozen snapshot | Read v2 of a session — versioning baked in |

For the **client-only locked deployment**:

```bash
npx multiplayer-workshop freeze --vercel <your-frozen-vercel-project> --session <your-session-id>
```

Builds a separate Vercel project with `VITE_CLIENT_ONLY=true`. That build:
- Always renders the client view, regardless of URL params
- Cannot be trimmed back to workshop
- Tree-shakes ALL multiplayer code from the bundle (verified by leak test)
- Serves the frozen session you specify

See [docs/freeze.md](./docs/freeze.md) for the full client-lock pattern.

---

## CLI commands

```bash
npx multiplayer-workshop init                       # scaffold into existing React+Convex project
npx multiplayer-workshop init --with-storyboards    # also copy the optional storyboard module templates
npx multiplayer-workshop status                     # show counts: open notes, current version, peers
npx multiplayer-workshop fork [label]               # fork a new version snapshot from current session
npx multiplayer-workshop freeze                     # build the locked client-only Vercel deployment
npx multiplayer-workshop handoff                    # print the Convex-pull prompt for Claude
```

---

## Updating

This package ships from a private GitHub repo, not the npm registry, so updates are git-based.

**Latest on `main`:**

```json
"@quexopa/multiplayer-workshop": "git+ssh://git@github.com/emperyalz/multiplayer-workshop.git#main"
```

```bash
npm update @quexopa/multiplayer-workshop
```

**Pin to a stable tag:**

```json
"@quexopa/multiplayer-workshop": "git+ssh://git@github.com/emperyalz/multiplayer-workshop.git#v1.0.0"
```

**Local dev (when iterating on the package itself):**

```bash
cd ~/multiplayer-workshop
npm link

cd ~/your-project
npm link @quexopa/multiplayer-workshop
# Edits to ~/multiplayer-workshop/src now reflect immediately in your project
```

For Claude Code plugin updates: `/plugin update multiplayer-workshop`

---

## Architecture

```
@quexopa/multiplayer-workshop
├── src/
│   ├── components/       React components (StickyNotes, VersionNavigator, ...)
│   ├── hooks/            useFields, usePresence
│   ├── lib/              identity, session, presentMode utils
│   ├── context.tsx       MultiplayerProvider — wraps user's app, provides api+config
│   ├── styles.css        Workshop chrome CSS
│   ├── convex/templates/ schema + function files copied into user's convex/
│   └── index.ts          public API surface
├── cli/                  npx multiplayer-workshop ...
└── package.json
```

The Convex functions in `src/convex/templates/` are not bundled into `dist/`. They're copied into the user's project by the CLI scaffolder. This is because Convex requires functions to live in the user's own `convex/` directory to register them.

---

## Requirements

- React 18 or 19
- Convex 1.17+
- Vite (recommended; works with other bundlers)
- TypeScript (strongly recommended)

---

## License

UNLICENSED — internal use by QueXopa team. Do not redistribute.
