#!/usr/bin/env node
// Add an auto-update prebuild step to every file:-tarball consumer.
//
// Consumers installing via `file:vendor/*.tgz` freeze at whatever tarball was
// vendored. This script sets each such consumer's `scripts.prebuild` to pull
// the latest published tarball at build time:
//
//   npm install --no-save https://mw-version-manifest.vercel.app/multiplayer-workshop-latest.tgz || true
//
// The trailing `|| true` keeps offline/local builds working — on failure the
// vendored file: tarball already in node_modules is used as the fallback.
// git+ consumers are skipped (they already auto-update by pulling #main).
//
// Run from the package root:  node cli/add-prebuild.mjs [--roots a,b]
// Idempotent: consumers whose prebuild already matches are skipped.

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execSync } from 'node:child_process';

const args = process.argv.slice(2);
const rootsArg = args.find((a) => a.startsWith('--roots='));
const SCAN_ROOTS = rootsArg
  ? rootsArg.slice('--roots='.length).split(',')
  : [os.homedir(), path.join(os.homedir(), 'Documents')];

const PKG = '@quexopa/multiplayer-workshop';
const PREBUILD =
  'npm install --no-save https://mw-version-manifest.vercel.app/multiplayer-workshop-latest.tgz || true';

// ─── Consumer discovery (same approach as cli/sync-consumers.mjs) ───────────
function findConsumers() {
  const found = new Map(); // dir → { spec, pjPath, json }
  for (const r of SCAN_ROOTS) {
    let out = '';
    try {
      out = execSync(
        `find "${r}" -maxdepth 5 -name package.json -not -path "*/node_modules/*" 2>/dev/null`,
        { encoding: 'utf8', maxBuffer: 1024 * 1024 * 32 },
      );
    } catch (e) {
      // Keep partial find output on permission errors.
      out = e && e.stdout ? String(e.stdout) : '';
    }
    for (const pj of out.split('\n').filter(Boolean)) {
      const dir = path.dirname(pj);
      if (dir.includes(`${path.sep}multiplayer-workshop${path.sep}`)) continue;
      if (found.has(dir)) continue;
      let json;
      try {
        json = JSON.parse(fs.readFileSync(pj, 'utf8'));
      } catch {
        continue;
      }
      if (json.name === PKG) continue; // the package itself
      const spec = json.dependencies?.[PKG] || json.devDependencies?.[PKG];
      if (spec) found.set(dir, { spec, pjPath: pj, json });
    }
  }
  return found;
}

const consumers = findConsumers();
console.log(`• found ${consumers.size} local consumer(s)\n`);

let updated = 0;
let unchanged = 0;
let skippedGit = 0;
let skippedOther = 0;

for (const [dir, { spec, pjPath, json }] of consumers) {
  const name = path.basename(dir);
  if (spec.includes('github.com') || spec.includes('git+')) {
    console.log(`skip ${name} (git spec — already auto-updates)`);
    skippedGit++;
    continue;
  }
  if (!spec.startsWith('file:')) {
    console.log(`skip ${name} (spec: ${spec})`);
    skippedOther++;
    continue;
  }
  if (json.scripts?.prebuild === PREBUILD) {
    console.log(`skip ${name} (prebuild already set)`);
    unchanged++;
    continue;
  }
  json.scripts = json.scripts || {};
  json.scripts.prebuild = PREBUILD;
  fs.writeFileSync(pjPath, JSON.stringify(json, null, 2) + '\n');
  console.log(`✓ ${name} → prebuild set`);
  updated++;
}

console.log(
  `\nDone: ${updated} updated, ${unchanged} already set, ${skippedGit} git+ skipped, ${skippedOther} other skipped.`,
);
