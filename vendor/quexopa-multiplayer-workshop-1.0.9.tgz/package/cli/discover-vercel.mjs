#!/usr/bin/env node
// FULL-VERCEL discovery: list EVERY project on the team, resolve its production
// alias(es) (custom domains first), probe the live site's JS bundles for
// Multiplayer markers, and seed/refresh the registry for every hit.
//
// This is the authoritative sweep — unlike seed-registry.mjs (which only sees
// local checkouts), this catches deployments whose source lives elsewhere
// (Codex-launched, older laptops, deleted local dirs, custom domains like
// askorwell.com / geoaudiences.com).
//
// Detection: fetch the production URL's HTML, collect script srcs (and inline
// module refs), fetch each and grep for package markers. Gated sites (401/307
// with no readable bundles) are recorded as "unknown" with a 'gated' tag so
// they surface in the dashboard for manual confirmation rather than silently
// disappearing.
//
// Usage: node cli/discover-vercel.mjs [--dry]

import fs from 'node:fs';
import os from 'node:os';

const DRY = process.argv.includes('--dry');
const TEAM = 'team_a06hPQt8eiGGuT4QIVLOmoPY';
const REGISTER = 'https://polished-horse-651.convex.site/mw/register';
const MARKERS = ['sticky-mode-overlay', 'mw-scope', 'multiplayer-topbar', 'ws:action-toggle-edit'];

const token = JSON.parse(
  fs.readFileSync(os.homedir() + '/Library/Application Support/com.vercel.cli/auth.json', 'utf8'),
).token;
const H = { Authorization: `Bearer ${token}` };

async function listAllProjects() {
  const out = [];
  let until = null;
  for (let page = 0; page < 20; page++) {
    const url = `https://api.vercel.com/v9/projects?teamId=${TEAM}&limit=100${until ? `&until=${until}` : ''}`;
    const res = await fetch(url, { headers: H });
    const json = await res.json();
    if (!res.ok) throw new Error(json?.error?.message || `projects list HTTP ${res.status}`);
    out.push(...(json.projects ?? []));
    const next = json?.pagination?.next;
    if (!next) break;
    until = next;
  }
  return out;
}

// Preferred production URL: custom domain first, then the clean .vercel.app
// alias (shortest, non-"-erics-projects-" one).
function prodUrls(project) {
  const aliases = project?.targets?.production?.alias ?? [];
  const custom = aliases.filter((a) => !a.endsWith('.vercel.app'));
  const clean = aliases
    .filter((a) => a.endsWith('.vercel.app') && !a.includes('-erics-projects-') && !a.includes('eric-3334'))
    .sort((a, b) => a.length - b.length);
  const rest = aliases.filter((a) => !custom.includes(a) && !clean.includes(a));
  return [...custom, ...clean, ...rest];
}

async function fetchText(url, ms = 12000) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    const res = await fetch(url, { redirect: 'follow', signal: ctl.signal });
    const text = await res.text();
    return { status: res.status, text, finalUrl: res.url };
  } catch {
    return { status: 0, text: '', finalUrl: url };
  } finally {
    clearTimeout(t);
  }
}

function scriptSrcs(html, base) {
  const srcs = new Set();
  for (const m of html.matchAll(/src="([^"]+\.js[^"]*)"/g)) {
    try { srcs.add(new URL(m[1], base).href); } catch {}
  }
  for (const m of html.matchAll(/href="([^"]+\.css[^"]*)"/g)) {
    try { srcs.add(new URL(m[1], base).href); } catch {}
  }
  return [...srcs].slice(0, 12);
}

function hasMarker(text) {
  return MARKERS.some((m) => text.includes(m));
}

async function probe(url) {
  const page = await fetchText(url);
  if (page.status === 0) return { verdict: 'unreachable' };
  if (page.status >= 400 && page.status !== 401 && page.status !== 403) return { verdict: 'error', status: page.status };
  if (hasMarker(page.text)) return { verdict: 'multiplayer' }; // inline/self-injected marker in HTML
  const assets = scriptSrcs(page.text, page.finalUrl || url);
  const entryTexts = [];
  for (const a of assets) {
    const js = await fetchText(a);
    if (hasMarker(js.text)) return { verdict: 'multiplayer' };
    entryTexts.push({ base: a, text: js.text });
  }
  // Lazy-chunk chase (1 level): admin-gated hosts code-split the Multiplayer
  // overlay, so the marker lives in a dynamically-imported chunk that never
  // appears in the landing HTML (real case: geoaudiences.com / qx-site11).
  // Entry bundles reference those chunks as "./Chunk-Xyz.js" string literals.
  const chunkUrls = new Set();
  for (const { base, text } of entryTexts) {
    for (const m of text.matchAll(/["'`]([./A-Za-z0-9_-]{2,80}\.js)["'`]/g)) {
      const ref = m[1];
      if (!/\.js$/.test(ref) || ref.startsWith('http')) continue;
      try {
        const u = new URL(ref, base).href;
        if (u.includes('/assets/') || /chunk|admin|multiplayer|overlay/i.test(ref)) chunkUrls.add(u);
      } catch {}
    }
    if (chunkUrls.size > 30) break;
  }
  for (const u of [...chunkUrls].slice(0, 30)) {
    const js = await fetchText(u);
    if (hasMarker(js.text)) return { verdict: 'multiplayer' };
  }
  if (page.status === 401 || page.status === 403 || /Authentication Required|password/i.test(page.text.slice(0, 2000))) {
    return { verdict: 'gated' };
  }
  return { verdict: 'no-multiplayer', assetsChecked: assets.length + chunkUrls.size };
}

const projects = await listAllProjects();
console.log(`Scanning ${projects.length} Vercel projects…\n`);

let found = 0, gated = 0, none = 0, dead = 0;
for (const p of projects) {
  const urls = prodUrls(p);
  if (urls.length === 0) { dead++; continue; }
  const primary = `https://${urls[0]}`;
  const r = await probe(primary);
  if (r.verdict === 'multiplayer' || r.verdict === 'gated') {
    const tag = r.verdict === 'gated' ? 'gated' : 'verified';
    r.verdict === 'gated' ? gated++ : found++;
    console.log(`  ${r.verdict === 'gated' ? '🔒' : '✓'} ${p.name} → ${primary}`);
    if (!DRY) {
      await fetch(REGISTER, {
        method: 'POST',
        body: JSON.stringify({
          origin: primary,
          url: primary,
          title: p.name,
          version: 'unknown',
          vercelProject: p.name,
          tags: [tag],
        }),
      }).catch(() => {});
    }
  } else if (r.verdict === 'no-multiplayer') {
    none++;
  } else {
    dead++;
  }
}
console.log(`\nDone: ${found} multiplayer, ${gated} gated (registered for manual check), ${none} without, ${dead} unreachable/no-alias.`);
