#!/usr/bin/env node
// =============================================================================
// Post-build: add .js extensions to relative imports in dist/
// =============================================================================
// TypeScript compiles `import './foo'` without extension, but Node ESM requires
// explicit extensions. Vite is lenient but Node isn't. This script walks dist/
// and rewrites every relative import to include the correct extension.
// =============================================================================

import { readdirSync, readFileSync, writeFileSync, statSync, existsSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DIST = resolve(__dirname, '..', 'dist');

function* walk(dir) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) yield* walk(full);
    else yield full;
  }
}

// Match `from '...'` and `from "..."` for relative paths
const RE = /\bfrom\s+(['"])(\.{1,2}\/[^'"]+)(['"])/g;

let totalFiles = 0, totalRewrites = 0;

for (const file of walk(DIST)) {
  if (!/\.(js|d\.ts)$/.test(file)) continue;
  const src = readFileSync(file, 'utf8');
  const fileDir = dirname(file);
  let didChange = false;

  const out = src.replace(RE, (match, quote1, importPath, quote2) => {
    // Already has an extension we recognize? Leave it.
    if (/\.(js|mjs|cjs|json|css)$/.test(importPath)) return match;

    const resolved = resolve(fileDir, importPath);

    // Resolve to: <file>.js if it exists, else <dir>/index.js
    let resolvedPath;
    if (existsSync(resolved + '.js')) resolvedPath = importPath + '.js';
    else if (existsSync(join(resolved, 'index.js'))) resolvedPath = importPath + '/index.js';
    else if (existsSync(resolved + '.d.ts')) resolvedPath = importPath + '.js';
    else if (existsSync(join(resolved, 'index.d.ts'))) resolvedPath = importPath + '/index.js';
    else {
      console.warn(`! Could not resolve ${importPath} from ${file} — leaving as-is`);
      return match;
    }

    didChange = true;
    totalRewrites++;
    return `from ${quote1}${resolvedPath}${quote2}`;
  });

  if (didChange) {
    writeFileSync(file, out);
    totalFiles++;
  }
}

console.log(`fix-esm-imports: rewrote ${totalRewrites} import${totalRewrites === 1 ? '' : 's'} across ${totalFiles} file${totalFiles === 1 ? '' : 's'}`);
