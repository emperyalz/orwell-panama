#!/usr/bin/env node
// =============================================================================
// @quexopa/multiplayer-workshop — CLI
// =============================================================================
// Entry point for `npx multiplayer-workshop ...` commands. Keeps logic in one
// place so the Claude Code plugin can shell out to this same CLI.
// =============================================================================

import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { existsSync, readFileSync, writeFileSync, mkdirSync, copyFileSync, readdirSync } from 'node:fs';
import { execSync, spawnSync } from 'node:child_process';
import { createInterface } from 'node:readline';

const __dirname = dirname(fileURLToPath(import.meta.url));
const PKG_ROOT = resolve(__dirname, '..');
const TEMPLATES_DIR = join(PKG_ROOT, 'src', 'convex', 'templates');

// ANSI colors
const c = {
  reset: '\x1b[0m', dim: '\x1b[2m', bold: '\x1b[1m',
  red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m',
  blue: '\x1b[34m', magenta: '\x1b[35m', cyan: '\x1b[36m',
};

function log(msg) { console.log(msg); }
function ok(msg) { console.log(`${c.green}✓${c.reset} ${msg}`); }
function warn(msg) { console.log(`${c.yellow}!${c.reset} ${msg}`); }
function err(msg) { console.error(`${c.red}✗${c.reset} ${msg}`); }
function step(msg) { console.log(`\n${c.bold}${c.cyan}→${c.reset} ${c.bold}${msg}${c.reset}`); }

async function ask(question, defaultAnswer = '') {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const promptText = defaultAnswer
    ? `${c.cyan}?${c.reset} ${question} ${c.dim}(${defaultAnswer})${c.reset} `
    : `${c.cyan}?${c.reset} ${question} `;
  return new Promise((resolveP) => {
    rl.question(promptText, (answer) => {
      rl.close();
      resolveP(answer.trim() || defaultAnswer);
    });
  });
}

// ---------------------------------------------------------------------------
// init — scaffold the multiplayer system into an existing React+Convex project
// ---------------------------------------------------------------------------

async function cmdInit() {
  step('Multiplayer Workshop — install');

  const cwd = process.cwd();

  // Verify this looks like a React+Vite+Convex project
  const pkgJsonPath = join(cwd, 'package.json');
  if (!existsSync(pkgJsonPath)) {
    err('No package.json found. Run this from your project root.');
    process.exit(1);
  }
  const pkgJson = JSON.parse(readFileSync(pkgJsonPath, 'utf8'));
  const allDeps = { ...pkgJson.dependencies, ...pkgJson.devDependencies };

  if (!allDeps.react) {
    err('No React detected in dependencies. This package requires React 18+.');
    process.exit(1);
  }
  if (!allDeps.convex) {
    warn('No Convex detected. Install with: npm install convex');
  }

  // Find the convex/ directory
  const convexDir = join(cwd, 'convex');
  if (!existsSync(convexDir)) {
    warn(`No convex/ directory at ${convexDir}.`);
    const create = await ask('Create it now?', 'y');
    if (create.toLowerCase().startsWith('y')) {
      mkdirSync(convexDir, { recursive: true });
      ok('Created convex/');
    } else {
      err('Aborted — Convex is required.');
      process.exit(1);
    }
  }

  // Gather config
  const convexDeployment = await ask('Convex deployment name (e.g. happy-cat-123)');
  const brandName = await ask('Project / brand name', pkgJson.name || 'My Workshop');
  const primaryColor = await ask('Primary brand color (hex)', '#C8102E');

  step('Copying Convex function templates');

  // CLI flag — pass `--with-storyboards` to also copy the optional storyboard
  // module's templates (storyboardSchema.ts, storyboards.ts, slides.ts,
  // styleBible.ts, slideReferences.ts, visionCaption.ts, visionCaptionAction.ts).
  const withStoryboards = process.argv.includes('--with-storyboards');

  // Top-level templates only — `storyboard/` subdirectory is opt-in.
  const filesToCopy = readdirSync(TEMPLATES_DIR).filter((f) => f.endsWith('.ts'));
  let copied = 0, skipped = 0;
  for (const file of filesToCopy) {
    const src = join(TEMPLATES_DIR, file);
    const dst = join(convexDir, file);
    if (existsSync(dst)) {
      const overwrite = await ask(`  ${file} already exists — overwrite?`, 'n');
      if (!overwrite.toLowerCase().startsWith('y')) {
        warn(`  Skipped ${file}`);
        skipped++;
        continue;
      }
    }
    copyFileSync(src, dst);
    ok(`  Copied ${file}`);
    copied++;
  }

  if (withStoryboards) {
    step('Copying storyboard module templates');
    const sbDir = join(TEMPLATES_DIR, 'storyboard');
    if (existsSync(sbDir)) {
      const sbFiles = readdirSync(sbDir).filter((f) => f.endsWith('.ts'));
      for (const file of sbFiles) {
        const src = join(sbDir, file);
        const dst = join(convexDir, file);
        if (existsSync(dst)) {
          const overwrite = await ask(`  ${file} already exists — overwrite?`, 'n');
          if (!overwrite.toLowerCase().startsWith('y')) {
            warn(`  Skipped ${file}`);
            skipped++;
            continue;
          }
        }
        copyFileSync(src, dst);
        ok(`  Copied ${file}`);
        copied++;
      }
      log('');
      log(`  ${c.yellow}Manual step:${c.reset} also spread ${c.cyan}storyboardTables${c.reset} into ${c.cyan}convex/schema.ts${c.reset}:\n`);
      log(`    ${c.dim}import { multiplayerTables } from './multiplayerSchema';${c.reset}`);
      log(`    ${c.dim}import { storyboardTables } from './storyboardSchema';${c.reset}`);
      log(`    ${c.dim}export default defineSchema({ ...multiplayerTables, ...storyboardTables });${c.reset}`);
      log('');
      log(`  ${c.yellow}Optional:${c.reset} set ${c.cyan}GEMINI_API_KEY${c.reset} for vision auto-captioning:\n`);
      log(`    ${c.dim}npx convex env set GEMINI_API_KEY=<your-key>${c.reset}\n`);
    } else {
      warn('  No storyboard templates found in this package version.');
    }
  }

  step('Schema integration');
  const schemaPath = join(convexDir, 'schema.ts');
  if (existsSync(schemaPath)) {
    const existing = readFileSync(schemaPath, 'utf8');
    if (existing.includes('multiplayerTables')) {
      ok('  Schema already imports multiplayerTables — no changes needed');
    } else {
      log(`  ${c.yellow}Manual step required:${c.reset} edit ${c.cyan}convex/schema.ts${c.reset} to add:\n`);
      log(`    ${c.dim}import { multiplayerTables } from './multiplayerSchema';${c.reset}`);
      log(`    ${c.dim}export default defineSchema({ ...multiplayerTables, /* your tables */ });${c.reset}\n`);
    }
  } else {
    log(`  ${c.yellow}No convex/schema.ts found.${c.reset} Use the bundled multiplayerSchema.ts as your schema, or create one:\n`);
    log(`    ${c.dim}export { default } from './multiplayerSchema';${c.reset}\n`);
  }

  step('Frontend integration');
  log(`  ${c.yellow}Manual step required:${c.reset} wrap your app with ${c.cyan}<MultiplayerProvider>${c.reset}.\n`);
  log(`  In your ${c.cyan}main.tsx${c.reset} (or ${c.cyan}App.tsx${c.reset}):\n`);
  log(`${c.dim}    import { MultiplayerProvider } from '@quexopa/multiplayer-workshop';`);
  log(`    import { api } from './convex/_generated/api';`);
  log(`    import '@quexopa/multiplayer-workshop/styles.css';`);
  log(``);
  log(`    <MultiplayerProvider`);
  log(`      api={api}`);
  log(`      config={{`);
  log(`        convexDeployment: '${convexDeployment}',`);
  log(`        brand: { name: '${brandName}', primaryColor: '${primaryColor}' },`);
  log(`      }}`);
  log(`    >`);
  log(`      <App />`);
  log(`    </MultiplayerProvider>${c.reset}`);
  log(``);

  log(`  Then in your ${c.cyan}App.tsx${c.reset}, mount the multiplayer chrome:\n`);
  log(`${c.dim}    import { StickyNotesProvider, VersionNavigator, getSessionId, loadIdentity } from '@quexopa/multiplayer-workshop';`);
  log(``);
  log(`    const sessionId = getSessionId();`);
  log(`    const identity = loadIdentity();`);
  log(``);
  log(`    return (<>`);
  log(`      <YourApp />`);
  log(`      <StickyNotesProvider sessionId={sessionId} identity={identity} />`);
  log(`      <VersionNavigator sessionId={sessionId} identity={identity} />`);
  log(`    </>);${c.reset}\n`);

  step('Done');
  ok(`Copied ${copied} Convex template${copied === 1 ? '' : 's'}, skipped ${skipped}`);
  log(`\n${c.bold}Next steps:${c.reset}`);
  log(`  1. Edit ${c.cyan}convex/schema.ts${c.reset} per the snippet above`);
  log(`  2. Run ${c.cyan}npx convex dev${c.reset} to push the schema`);
  log(`  3. Wrap your app with ${c.cyan}<MultiplayerProvider>${c.reset}`);
  log(`  4. Mount ${c.cyan}<StickyNotesProvider>${c.reset} + ${c.cyan}<VersionNavigator>${c.reset}`);
  log(`  5. Run ${c.cyan}npm run dev${c.reset} and visit ${c.cyan}/?session=test${c.reset}`);
  log(``);
  log(`When you're ready to lock a client-only deployment:`);
  log(`  ${c.cyan}npx multiplayer-workshop freeze${c.reset}`);
}

// ---------------------------------------------------------------------------
// status — show what's in the current session
// ---------------------------------------------------------------------------

async function cmdStatus() {
  step('Multiplayer Workshop — status');
  log(`\n${c.dim}This requires a Convex client connection. Best run inside your project's${c.reset}`);
  log(`${c.dim}browser console: ${c.reset}${c.cyan}fetch your session via the Convex hooks.${c.reset}\n`);
  log(`Or paste the handoff prompt into Claude — it'll fetch from Convex directly:\n`);
  await cmdHandoff();
}

// ---------------------------------------------------------------------------
// fork — create a new version snapshot of the current session
// ---------------------------------------------------------------------------

async function cmdFork() {
  step('Fork a new version');
  log(`\nThis is best done from inside your app via the Version Navigator (📚 button).`);
  log(`Or use the Convex CLI:\n`);
  log(`  ${c.cyan}npx convex run sessions:createVersion '{"sourceSessionId": "<current>", "actor": "<your-name>"}'${c.reset}\n`);
}

// ---------------------------------------------------------------------------
// handoff — print the Convex-pull prompt for Claude
// ---------------------------------------------------------------------------

async function cmdHandoff() {
  const sessionId = process.argv[3] || (await ask('Session ID', 'workshop-' + new Date().toISOString().slice(0, 10)));
  const deployment = process.argv[4] || (await ask('Convex deployment name', ''));

  if (!deployment) {
    err('Convex deployment name required.');
    process.exit(1);
  }

  const prompt = `Pull the latest from Convex deployment ${deployment}, session ${sessionId}, and act on every unresolved sticky note + decision.`;

  step('Hand-off prompt');
  log(`\n${c.bold}Paste this into Claude:${c.reset}\n`);
  log(`${c.green}${prompt}${c.reset}\n`);
  log(`${c.dim}Tip: copy directly with: ${c.reset}${c.cyan}npx multiplayer-workshop handoff <sessionId> <deployment> | pbcopy${c.reset}\n`);
}

// ---------------------------------------------------------------------------
// freeze — build & deploy a locked client-only Vercel project
// ---------------------------------------------------------------------------

async function cmdFreeze() {
  step('Freeze client-only Vercel deployment');

  const cwd = process.cwd();
  const pkgJsonPath = join(cwd, 'package.json');
  if (!existsSync(pkgJsonPath)) {
    err('Run this from your project root.');
    process.exit(1);
  }

  log(`\nThis creates a SEPARATE Vercel project that:`);
  log(`  • renders the client view regardless of URL params`);
  log(`  • cannot be trimmed back to workshop`);
  log(`  • tree-shakes ALL multiplayer code from the bundle`);
  log(`  • serves a frozen session ID baked into the build\n`);

  const projectName = await ask('New Vercel project name', 'my-proposal-client');
  const sessionId = await ask('Session ID to freeze (e.g. workshop-2026-04-23-v2)');

  if (!sessionId) {
    err('Session ID required.');
    process.exit(1);
  }

  step('Pre-flight checks');

  // Check vercel CLI
  try {
    execSync('vercel --version', { stdio: 'pipe' });
    ok('Vercel CLI installed');
  } catch {
    err('Vercel CLI not found. Install: npm install -g vercel');
    process.exit(1);
  }

  // Check that the project's App.tsx supports VITE_CLIENT_ONLY
  const appTsxCandidates = [
    join(cwd, 'src', 'App.tsx'),
    join(cwd, 'src', 'App.jsx'),
    join(cwd, 'src', 'main.tsx'),
  ];
  let appTsx;
  for (const candidate of appTsxCandidates) {
    if (existsSync(candidate)) { appTsx = candidate; break; }
  }
  if (!appTsx) {
    err('No App.tsx / App.jsx / main.tsx found in src/.');
    process.exit(1);
  }
  const appSrc = readFileSync(appTsx, 'utf8');
  if (!appSrc.includes('VITE_CLIENT_ONLY')) {
    warn(`Your ${appTsx} does NOT check VITE_CLIENT_ONLY.`);
    log(`\nAdd this branch to your App() function:\n`);
    log(`${c.dim}  const CLIENT_ONLY = ((import.meta as any).env?.VITE_CLIENT_ONLY === 'true');`);
    log(`  const CLIENT_SESSION_ID = '${sessionId}';`);
    log(``);
    log(`  if (CLIENT_ONLY) return <ClientApp sessionId={CLIENT_SESSION_ID} />;${c.reset}\n`);
    log(`See https://github.com/emperyalz/multiplayer-workshop/blob/main/docs/freeze.md for the full pattern.\n`);
    const proceed = await ask('Proceed anyway?', 'n');
    if (!proceed.toLowerCase().startsWith('y')) process.exit(0);
  } else {
    ok('App.tsx already has VITE_CLIENT_ONLY branch');
  }

  step('Linking new Vercel project');

  // Back up existing .vercel
  const dotVercel = join(cwd, '.vercel');
  const backup = join(cwd, '.vercel-workshop-link');
  let didBackup = false;
  if (existsSync(dotVercel)) {
    if (existsSync(backup)) {
      err(`${backup} already exists. Move/delete it first.`);
      process.exit(1);
    }
    spawnSync('mv', [dotVercel, backup], { stdio: 'inherit' });
    didBackup = true;
    ok('Backed up workshop .vercel link');
  }

  try {
    spawnSync('vercel', ['link', '--yes', '--project', projectName], { stdio: 'inherit', cwd });

    step('Setting VITE_CLIENT_ONLY=true on the new project');
    const envProc = spawnSync('vercel', ['env', 'add', 'VITE_CLIENT_ONLY', 'production'], {
      input: 'true\n',
      stdio: ['pipe', 'inherit', 'inherit'],
      cwd,
    });
    if (envProc.status !== 0) {
      warn('vercel env add returned non-zero — env var may already exist. Continuing.');
    }

    step('Deploying to production');
    spawnSync('vercel', ['--prod', '--yes'], { stdio: 'inherit', cwd });

    ok(`\nDeployed: https://${projectName}.vercel.app`);
  } finally {
    // Restore workshop link
    if (didBackup) {
      const newClientLink = join(cwd, '.vercel-client-link');
      if (existsSync(dotVercel)) spawnSync('mv', [dotVercel, newClientLink], { stdio: 'inherit' });
      spawnSync('mv', [backup, dotVercel], { stdio: 'inherit' });
      ok('Restored workshop .vercel link');
      log(`${c.dim}Client project link saved to .vercel-client-link/ — to redeploy later, swap them.${c.reset}`);
    }
  }
}

// ---------------------------------------------------------------------------
// help
// ---------------------------------------------------------------------------

function cmdHelp() {
  log(`
${c.bold}@quexopa/multiplayer-workshop${c.reset} ${c.dim}— CLI${c.reset}

${c.bold}Commands:${c.reset}
  ${c.cyan}init${c.reset}        Scaffold multiplayer into an existing React+Convex project
  ${c.cyan}status${c.reset}      Show counts: open notes, current version, peers
  ${c.cyan}fork${c.reset}        Create a new version snapshot of the current session
  ${c.cyan}handoff${c.reset}     Print the Convex-pull prompt to send to Claude
  ${c.cyan}freeze${c.reset}      Build + deploy a locked client-only Vercel project
  ${c.cyan}help${c.reset}        Show this help

${c.bold}Examples:${c.reset}
  ${c.dim}npx multiplayer-workshop init${c.reset}
  ${c.dim}npx multiplayer-workshop init --with-storyboards${c.reset}
  ${c.dim}npx multiplayer-workshop handoff workshop-2026-04-23 happy-cat-123${c.reset}
  ${c.dim}npx multiplayer-workshop freeze${c.reset}

${c.bold}Docs:${c.reset} https://github.com/emperyalz/multiplayer-workshop
`);
}

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

const cmd = process.argv[2] || 'help';
const COMMANDS = {
  init: cmdInit,
  status: cmdStatus,
  fork: cmdFork,
  handoff: cmdHandoff,
  freeze: cmdFreeze,
  help: cmdHelp,
  '--help': cmdHelp,
  '-h': cmdHelp,
};

const fn = COMMANDS[cmd];
if (!fn) {
  err(`Unknown command: ${cmd}`);
  cmdHelp();
  process.exit(1);
}

try {
  await fn();
} catch (e) {
  err(e?.message || String(e));
  process.exit(1);
}
