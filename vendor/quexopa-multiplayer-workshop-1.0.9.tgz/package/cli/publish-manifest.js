#!/usr/bin/env node
// Updates the public version manifest at ~/mw-version-manifest/public/version.json
// to match this package's current version, then triggers a Vercel deploy of
// that project so the in-app version-check badge sees the new version on main.
//
// Run after pushing a new package version to main:
//   node cli/publish-manifest.js
//
// Pass --roll to ALSO redeploy every registry site flagged autoUpdate=true
// (dashboard "Auto" toggle): fetches the list via the internal Convex query
// deployments:listForRoll, then POSTs each vercelProject to the dashboard's
// /api/redeploy. Plain publishes (no flag) are completely unchanged.
//   node cli/publish-manifest.js --roll

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import os from 'os';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const pkgPath = path.resolve(__dirname, '..', 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));

const manifestDir = path.join(os.homedir(), 'mw-version-manifest');
const manifestFile = path.join(manifestDir, 'public', 'version.json');

// ── Frontend/backend release-train guard ────────────────────────────────────
// A frontend roll ships whatever fields the client now sends; consumer Convex
// BACKENDS only learn new fields via `sync-consumers --convex`. Publishing
// with unsynced template changes therefore breaks note creation fleet-wide
// (validators reject the new field → "Drop Note does nothing"). Hash the
// templates dir and AUTO-RUN the convex sync when it drifted from the last
// synced hash (sync-consumers writes .templates-synced-hash on success).
// Opt out with --skip-convex-sync (e.g. offline).
import crypto from 'crypto';
const templatesDir = path.resolve(__dirname, '..', 'src', 'convex', 'templates');
const syncedHashFile = path.join(__dirname, '.templates-synced-hash');
function templatesHash() {
  const h = crypto.createHash('sha256');
  const walk = (d) => {
    for (const f of fs.readdirSync(d).sort()) {
      const p = path.join(d, f);
      if (fs.statSync(p).isDirectory()) walk(p);
      else if (f.endsWith('.ts')) h.update(f).update(fs.readFileSync(p));
    }
  };
  walk(templatesDir);
  return h.digest('hex');
}
if (!process.argv.includes('--skip-convex-sync')) {
  const current = templatesHash();
  const synced = fs.existsSync(syncedHashFile) ? fs.readFileSync(syncedHashFile, 'utf8').trim() : '';
  if (current !== synced) {
    console.log('⚠ convex templates changed since the last fleet sync — running sync-consumers --convex first');
    try {
      execSync(`node ${path.join(__dirname, 'sync-consumers.mjs')} --convex`, { stdio: 'inherit' });
      fs.writeFileSync(syncedHashFile, current + '\n');
    } catch {
      console.error('✗ convex fleet sync FAILED — publishing anyway would break Drop Note on unsynced sites.');
      console.error('  Fix the sync (or pass --skip-convex-sync to override) and re-run.');
      process.exit(1);
    }
  }
}

if (!fs.existsSync(manifestDir)) {
  console.error(`Manifest project not found at ${manifestDir}.`);
  console.error('Clone or create it first — see ~/mw-version-manifest/README.md.');
  process.exit(1);
}

let commit = '';
try {
  commit = execSync('git rev-parse --short HEAD', { cwd: path.resolve(__dirname, '..') }).toString().trim();
} catch {
  // Not in a git checkout — fine.
}

const manifest = {
  version: pkg.version,
  publishedAt: new Date().toISOString(),
  package: pkg.name,
  repo: 'emperyalz/multiplayer-workshop',
  commit: commit || undefined,
  tarballUrl: 'https://mw-version-manifest.vercel.app/multiplayer-workshop-latest.tgz',
  notes: 'Public version manifest. Updated by `node cli/publish-manifest.js` in the package repo. Source for the in-app version-check badge.',
};

fs.writeFileSync(manifestFile, JSON.stringify(manifest, null, 2) + '\n');
console.log(`publish-manifest: wrote v${pkg.version} (${commit || 'no-git'}) to ${manifestFile}`);

// Also host the packed tarball publicly as multiplayer-workshop-latest.tgz.
// Consumers' `prebuild` (added by cli/add-prebuild.mjs) installs it at build
// time, which is what makes the dashboard's remote "Update" button a REAL
// update: a Vercel redeploy re-runs prebuild → pulls this latest tarball —
// no local machine needed. Trade-off: the compiled package becomes publicly
// downloadable at this URL (no secrets in it; accepted for velocity).
console.log('publish-manifest: packing tarball…');
const packOut = execSync('npm pack', { cwd: path.resolve(__dirname, '..'), encoding: 'utf8' });
const tgzName = packOut.trim().split('\n').pop().trim();
const tgzPath = path.resolve(__dirname, '..', tgzName);
fs.copyFileSync(tgzPath, path.join(manifestDir, 'public', 'multiplayer-workshop-latest.tgz'));
console.log(`publish-manifest: hosted ${tgzName} as multiplayer-workshop-latest.tgz`);

console.log('publish-manifest: deploying to Vercel…');
execSync('npx vercel --prod --yes', { cwd: manifestDir, stdio: 'inherit' });
console.log('publish-manifest: done — https://mw-version-manifest.vercel.app/version.json');

// ─── auto-roll: redeploy every site flagged autoUpdate=true ──────────────────
// Since 2026-08-04 this runs BY DEFAULT on every publish (the whole fleet is
// flagged), so a release upgrades every site with zero clicks. `--no-roll`
// opts out for manifest-only publishes; `--roll` is kept as a no-op alias.
if (!process.argv.slice(2).includes('--no-roll')) {
  const REDEPLOY_ENDPOINT = 'https://multiplayer-dashboard-alpha.vercel.app/api/redeploy';
  const cloudDir = path.resolve(__dirname, '..', 'cloud');

  console.log('publish-manifest: --roll — fetching auto-update sites…');
  let sites;
  try {
    // Internal query; the Convex CLI's admin auth is allowed to invoke it.
    const out = execSync('npx convex run deployments:listForRoll', {
      cwd: cloudDir,
      encoding: 'utf8',
    });
    // `convex run` prints the return value as JSON on stdout; be defensive
    // about any leading CLI chatter by parsing from the first bracket.
    const start = out.indexOf('[');
    if (start === -1) throw new Error(`no JSON array in convex run output:\n${out}`);
    sites = JSON.parse(out.slice(start));
  } catch (e) {
    console.error(`publish-manifest: --roll failed to list flagged sites: ${e.message}`);
    process.exit(1);
  }

  if (!Array.isArray(sites) || sites.length === 0) {
    console.log('publish-manifest: --roll — no sites flagged for auto-update; nothing to do.');
  } else {
    console.log(`publish-manifest: --roll — redeploying ${sites.length} flagged site(s)…`);
    let ok = 0;
    let failed = 0;
    for (const site of sites) {
      const label = `${site.origin} (${site.vercelProject})`;
      try {
        const res = await fetch(REDEPLOY_ENDPOINT, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ project: site.vercelProject }),
        });
        const json = await res.json().catch(() => ({}));
        if (res.ok && json?.ok) {
          ok++;
          console.log(`  ✓ ${label}${json.url ? ` → ${json.url}` : ''}`);
        } else {
          failed++;
          console.error(`  ✗ ${label} — ${json?.error || `HTTP ${res.status}`}`);
        }
      } catch (e) {
        failed++;
        console.error(`  ✗ ${label} — ${e.message}`);
      }
    }
    console.log(`publish-manifest: --roll complete — ${ok} ok, ${failed} failed.`);
    if (failed > 0) process.exitCode = 1;
  }
}
