#!/usr/bin/env python3
# =============================================================================
# Force-refresh the Vercel CLI's OAuth access token via its own refresh_token
# grant — the CLI only refreshes an EXPIRED token (`vercel whoami` on a token
# with 10 minutes left keeps it), so the token-medic could install a nearly-
# dead credential. This mints a fresh ~8h token on demand.
#
# Uses the CLI's PUBLIC client id and the token endpoint from Vercel's OIDC
# discovery document. The refresh token ROTATES on use, so auth.json is
# rewritten atomically with the new pair — skipping that write would brick the
# CLI session and force a manual `vercel login`.
#
# Prints the fresh access token to stdout (for the medic to install).
# =============================================================================
import json, os, sys, time, urllib.request, urllib.parse, tempfile

AUTH = os.path.expanduser("~/Library/Application Support/com.vercel.cli/auth.json")
CLIENT_ID = "cl_HYyOPBNtFMfHhaUn9L4QPfTZz6TP47bp"
TOKEN_URL = "https://api.vercel.com/login/oauth/token"

d = json.load(open(AUTH))
rt = d.get("refreshToken")
if not rt:
    print("no refreshToken in auth.json — run `vercel login`", file=sys.stderr)
    sys.exit(1)

body = urllib.parse.urlencode({
    "grant_type": "refresh_token",
    "client_id": CLIENT_ID,
    "refresh_token": rt,
}).encode()
req = urllib.request.Request(TOKEN_URL, data=body,
    headers={"content-type": "application/x-www-form-urlencoded"})
try:
    resp = json.loads(urllib.request.urlopen(req, timeout=30).read().decode())
except urllib.error.HTTPError as e:
    print(f"refresh failed HTTP {e.code}: {e.read().decode()[:200]}", file=sys.stderr)
    sys.exit(1)

access = resp.get("access_token")
new_rt = resp.get("refresh_token") or rt
expires_in = int(resp.get("expires_in") or 8 * 3600)
if not access:
    print(f"no access_token in response: {json.dumps(resp)[:200]}", file=sys.stderr)
    sys.exit(1)

# expiresAt in auth.json is UNIX SECONDS (observed format).
d["token"] = access
d["refreshToken"] = new_rt
d["expiresAt"] = int(time.time()) + expires_in

fd, tmp = tempfile.mkstemp(dir=os.path.dirname(AUTH))
with os.fdopen(fd, "w") as fh:
    json.dump(d, fh, indent=2)
os.replace(tmp, AUTH)

print(access)
