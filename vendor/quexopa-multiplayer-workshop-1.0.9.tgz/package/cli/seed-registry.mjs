#!/usr/bin/env node
// Seed the cloud deployment registry from LOCAL consumer checkouts.
//
// The beacon (registerDeployment) only registers a site once a real visitor
// loads it — this script backfills the registry immediately by walking every
// local consumer that is linked to a Vercel project, resolving its production
// alias via the Vercel API, and POSTing to the /mw/register endpoint.
//
// Run from the package root:  node cli/seed-registry.mjs [--roots a,b]
// Node built-ins only.

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execSync } from 'node:child_process';

const args = process.argv.slice(2);
const rootsArg = args.find((a) => a.startsWith('--roots='));
const SCAN_ROOTS = rootsArg
  ? rootsArg.slice('--roots='.length).split(',')
  : [os.homedir(), path.join(os.homedir(), 'Documents')];

const PKG = '@quexopa/multiplayer-workshop';
const ENDPOINT = 'https://polished-horse-651.convex.site/mw/register';
const TEAM_ID = 'team_a06hPQt8eiGGuT4QIVLOmoPY';

// ─── Consumer discovery (same approach as cli/sync-consumers.mjs) ───────────
function findConsumers() {
  const found = new Set(); // dirs
  for (const r of SCAN_ROOTS) {
    let out = '';
    try {
      out = execSync(
        `find "${r}" -maxdepth 5 -name package.json -not -path "*/node_modules/*" 2>/dev/null`,
        { encoding: 'utf8', maxBuffer: 1024 * 1024 * 32 },
      );
    } catch (e) {
      // `find` exits non-zero on permission errors but still prints what it
      // COULD read — keep the partial output.
      out = e && e.stdout ? String(e.stdout) : '';
    }
    for (const pj of out.split('\n').filter(Boolean)) {
      const dir = path.dirname(pj);
      if (dir.includes(`${path.sep}multiplayer-workshop${path.sep}`)) continue;
      if (found.has(dir)) continue;
      let json;
      try {
        json = JSON.parse(fs.readFileSync(pj, 'utf8'));
      } catch {
        continue;
      }
      if (json.name === PKG) continue; // the package itself
      const spec = json.dependencies?.[PKG] || json.devDependencies?.[PKG];
      if (spec) found.add(dir);
    }
  }
  return [...found];
}

// ─── Vercel auth ────────────────────────────────────────────────────────────
function vercelToken() {
  const authPath = path.join(
    os.homedir(),
    'Library/Application Support/com.vercel.cli/auth.json',
  );
  return JSON.parse(fs.readFileSync(authPath, 'utf8')).token;
}

/** Pick the best production alias: shortest '.vercel.app' that isn't the
 *  long auto-generated '-erics-projects' one; fall back to the first alias. */
function pickAlias(aliases) {
  if (!Array.isArray(aliases) || aliases.length === 0) return null;
  const clean = aliases
    .filter((a) => a.includes('.vercel.app') && !a.includes('-erics-projects'))
    .sort((a, b) => a.length - b.length);
  return clean[0] ?? aliases[0];
}

async function fetchProjectAlias(projectName, token) {
  const res = await fetch(
    `https://api.vercel.com/v9/projects/${encodeURIComponent(projectName)}?teamId=${TEAM_ID}`,
    { headers: { Authorization: `Bearer ${token}` } },
  );
  if (!res.ok) throw new Error(`Vercel API ${res.status} for ${projectName}`);
  const json = await res.json();
  return pickAlias(json?.targets?.production?.alias);
}

function installedVersion(dir) {
  try {
    const pj = path.join(dir, 'node_modules', PKG, 'package.json');
    return JSON.parse(fs.readFileSync(pj, 'utf8')).version || 'unknown';
  } catch {
    return 'unknown';
  }
}

// ─── Main ───────────────────────────────────────────────────────────────────
let token;
try {
  token = vercelToken();
} catch (e) {
  console.error(`✗ cannot read Vercel CLI auth token: ${e.message}`);
  process.exit(1);
}

const consumers = findConsumers();
console.log(`• found ${consumers.length} local consumer(s)\n`);

let ok = 0;
let failed = 0;
let skipped = 0;

for (const dir of consumers) {
  const name = path.basename(dir);
  const linkPath = path.join(dir, '.vercel', 'project.json');
  if (!fs.existsSync(linkPath)) {
    skipped++;
    continue; // not vercel-linked → nothing to seed
  }
  let projectName;
  try {
    projectName = JSON.parse(fs.readFileSync(linkPath, 'utf8')).projectName;
    if (!projectName) throw new Error('no projectName in .vercel/project.json');
  } catch (e) {
    console.log(`✗ ${name}: ${e.message}`);
    failed++;
    continue;
  }
  try {
    const alias = await fetchProjectAlias(projectName, token);
    if (!alias) throw new Error('no production alias');
    const version = installedVersion(dir);
    const res = await fetch(ENDPOINT, {
      method: 'POST',
      body: JSON.stringify({
        origin: `https://${alias}`,
        url: `https://${alias}`,
        title: projectName,
        version,
        vercelProject: projectName,
        tags: ['seeded'],
      }),
    });
    if (!res.ok) throw new Error(`register endpoint ${res.status}`);
    console.log(`✓ ${projectName} → https://${alias} (v${version})`);
    ok++;
  } catch (e) {
    console.log(`✗ ${projectName}: ${e.message}`);
    failed++;
  }
}

console.log(
  `\nDone: ${ok} seeded, ${failed} failed, ${skipped} skipped (not vercel-linked).`,
);
