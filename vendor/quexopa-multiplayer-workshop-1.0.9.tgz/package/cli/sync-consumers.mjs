#!/usr/bin/env node
// Re-sync EVERY local Multiplayer consumer to the current package version.
//
// The drift problem: each consumer that installs via `file:vendor/*.tgz` holds
// a COPY of the tarball, frozen at whenever it was added. They fall out of sync
// (different styling, missing fixes). This script makes "update everything" one
// command:
//   1. npm pack → fresh tarball
//   2. discover all consumers (scan for package.json referencing the package)
//   3. for each file:-tarball consumer: drop in the new tarball, clear its
//      lockfile + installed copy so the next `npm install`/deploy picks it up
//   4. report what was synced + what still needs a redeploy
//
// Run from the package root:  node cli/sync-consumers.mjs [--install] [--roots a,b]
//   --install   also run `npm install` in each consumer (slower; otherwise the
//               consumer reinstalls on its next build/deploy)
//
// It does NOT deploy — review the report, then redeploy the listed projects.
//
// ── Convex template sync ─────────────────────────────────────────────────────
//   node cli/sync-consumers.mjs --convex [--dry-run] [--skip=name1,name2]
//
// Propagates the package's convex/templates/*.ts into every consumer's convex/
// dir and pushes each consumer's Convex deployment so schema changes (e.g. the
// v1.0 anchorFingerprint field) actually reach the backend. Rules:
//   • only overwrites template files that ALREADY exist in the consumer —
//     never adds brand-new modules to a project
//   • a consumer file is overwritten only when it is a pure subset of the
//     current template (i.e. a stale copy). Files with consumer-authored lines
//     are NOT clobbered — for multiplayerSchema.ts / stickyNotes.ts the
//     anchorFingerprint additions are spliced in surgically instead
//   • deployment comes from .env.local/.env (CONVEX_DEPLOYMENT, else
//     VITE_CONVEX_URL / NEXT_PUBLIC_CONVEX_URL); several consumers share one
//     deployment, so pushes are grouped per deployment and run from the dir
//     whose convex/ file set is a superset of its siblings (a subset dir's
//     push would DELETE the siblings' live functions)
//   • never forces, never deletes data — push failures are reported verbatim

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const args = process.argv.slice(2);
const doInstall = args.includes('--install');
const doConvex = args.includes('--convex');
const dryRun = args.includes('--dry-run');
const skipArg = args.find((a) => a.startsWith('--skip='));
const rootsArg = args.find((a) => a.startsWith('--roots='));
const SCAN_ROOTS = rootsArg
  ? rootsArg.slice('--roots='.length).split(',')
  : [os.homedir(), path.join(os.homedir(), 'Documents')];

const PKG = '@quexopa/multiplayer-workshop';
const SELF = root;

function findConsumers() {
  const found = new Map(); // dir → spec
  for (const r of SCAN_ROOTS) {
    let out = '';
    try {
      // depth-limited find, skipping node_modules, for package.json mentioning the pkg
      out = execSync(
        `find "${r}" -maxdepth 5 -name package.json -not -path "*/node_modules/*" 2>/dev/null`,
        { encoding: 'utf8', maxBuffer: 1024 * 1024 * 32 },
      );
    } catch (e) {
      // `find` exits non-zero on permission errors but still prints the dirs it
      // COULD read to stdout — keep that partial output (the earlier bug threw
      // it all away, so only ~/Documents matched).
      out = (e && e.stdout) ? String(e.stdout) : '';
    }
    for (const pj of out.split('\n').filter(Boolean)) {
      const dir = path.dirname(pj);
      if (path.resolve(dir) === SELF) continue; // skip the package itself
      if (dir.includes(`${path.sep}multiplayer-workshop${path.sep}`)) continue; // skip cloud/extension subdirs
      if (found.has(dir)) continue;
      let json;
      try {
        json = JSON.parse(fs.readFileSync(pj, 'utf8'));
      } catch {
        continue;
      }
      const spec = json.dependencies?.[PKG] || json.devDependencies?.[PKG];
      if (spec) found.set(dir, spec);
    }
  }
  return found;
}

function repack() {
  console.log('• npm pack …');
  const out = execSync('npm pack', { cwd: root, encoding: 'utf8' });
  const tgz = out.trim().split('\n').pop().trim();
  return path.join(root, tgz);
}

// ═════════════════════════════════════════════════════════════════════════════
// --convex mode: propagate convex/templates into consumers + push deployments
// ═════════════════════════════════════════════════════════════════════════════

const TEMPLATES_DIR = path.join(root, 'src', 'convex', 'templates');

// Consumers we must NOT touch, with the reason (situational — trim as the
// fleet catches up):
const CONVEX_SKIP = {
  'quexopa-overview': 'hidden-labrador-12 already migrated (v1.0 rollout)',
  'huawei-brief': 'rosy-marmot-518 already migrated; on-disk templates current',
  'huawei-proposal': 'rosy-marmot-518 already migrated; on-disk templates current',
  QX_site10: 'drifted — do not touch',
  'qx-site10': 'drifted — do not touch',
};

function normalizeLine(l) {
  return l.replace(/\s+/g, ' ').trim();
}

function normalizedLines(src) {
  return src.split('\n').map(normalizeLine).filter(Boolean);
}

// A consumer file counts as a STALE template copy when every one of its lines
// (whitespace-normalized) also appears in the current template — i.e. it holds
// no consumer-authored content and overwriting it only ADDS what the template
// gained since. Anything else is locally modified and must not be clobbered.
function classifyTemplateCopy(templateSrc, consumerSrc) {
  const tLines = new Set(normalizedLines(templateSrc));
  const cLines = normalizedLines(consumerSrc);
  if (cLines.join('\n') === normalizedLines(templateSrc).join('\n')) return 'current';
  return cLines.every((l) => tLines.has(l)) ? 'stale' : 'modified';
}

const AF_SCHEMA_BLOCK = [
  '    // v1.0 — structured anchor fingerprint (text hash, tag path, landmark',
  '    // offsets…) so aimed notes can be re-located after the DOM changes. See',
  "    // the package's src/lib/anchor. All-optional so old rows stay valid.",
  '    anchorFingerprint: v.optional(',
  '      v.object({',
  '        textHash: v.optional(v.string()),',
  '        tagPath: v.optional(v.array(v.string())),',
  '        classChain: v.optional(v.array(v.array(v.string()))),',
  '        selfId: v.optional(v.string()),',
  '        ancestorIds: v.optional(v.array(v.string())),',
  '        landmarkSelector: v.optional(v.string()),',
  '        landmarkDx: v.optional(v.number()),',
  '        landmarkDy: v.optional(v.number()),',
  '        initialRect: v.optional(',
  '          v.object({ x: v.number(), y: v.number(), w: v.number(), h: v.number() }),',
  '        ),',
  '        url: v.optional(v.string()),',
  '      }),',
  '    ),',
];

const AF_VALIDATOR_BLOCK = [
  '// Shared with the schema — the structured anchor fingerprint (v1.0).',
  'const anchorFingerprintValidator = v.object({',
  '  textHash: v.optional(v.string()),',
  '  tagPath: v.optional(v.array(v.string())),',
  '  classChain: v.optional(v.array(v.array(v.string()))),',
  '  selfId: v.optional(v.string()),',
  '  ancestorIds: v.optional(v.array(v.string())),',
  '  landmarkSelector: v.optional(v.string()),',
  '  landmarkDx: v.optional(v.number()),',
  '  landmarkDy: v.optional(v.number()),',
  '  initialRect: v.optional(',
  '    v.object({ x: v.number(), y: v.number(), w: v.number(), h: v.number() }),',
  '  ),',
  '  url: v.optional(v.string()),',
  '});',
  '',
];

const ANCHOR_SELECTOR_RE = /^\s*anchorSelector: v\.optional\(v\.string\(\)\),\s*$/;
const AF_ARG_LINE = '    anchorFingerprint: v.optional(anchorFingerprintValidator),';

// Splice the anchorFingerprint field into a locally-modified multiplayerSchema
// copy (right after the stickyNotes table's anchorSelector). Returns the new
// source, or null when there's no safe insertion point.
function spliceAFIntoSchema(src) {
  if (src.includes('anchorFingerprint')) return src; // already there
  const lines = src.split('\n');
  const i = lines.findIndex((l) => ANCHOR_SELECTOR_RE.test(l));
  if (i === -1) return null;
  lines.splice(i + 1, 0, ...AF_SCHEMA_BLOCK);
  return lines.join('\n');
}

// Splice the validator + `anchorFingerprint` args into a locally-modified
// stickyNotes copy: validator const before `export const add`, and the arg
// line after `anchorSelector` inside the add + update arg blocks only (NOT
// duplicate's). Returns the new source, or null when unsafe.
function spliceAFIntoStickyNotes(src) {
  if (src.includes('anchorFingerprint')) return src; // already there
  const lines = src.split('\n');
  const addIdx = lines.findIndex((l) => l.startsWith('export const add = mutation'));
  if (addIdx === -1) return null;
  lines.splice(addIdx, 0, ...AF_VALIDATOR_BLOCK);

  const insertInBlock = (marker) => {
    const start = lines.findIndex((l) => l.startsWith(marker));
    if (start === -1) return false;
    for (let i = start; i < lines.length; i++) {
      if (/^\s*handler:/.test(lines[i])) return false; // args ended, no anchor
      if (ANCHOR_SELECTOR_RE.test(lines[i])) {
        lines.splice(i + 1, 0, AF_ARG_LINE);
        return true;
      }
    }
    return false;
  };
  if (!insertInBlock('export const add = mutation')) return null;
  if (!insertInBlock('export const update = mutation')) return null;
  return lines.join('\n');
}

// v1.0.5 'scope' field: same treatment as anchorFingerprint. LESSON (learned
// the hard way 2026-07-27): a "modified" consumer copy that we splice must
// receive EVERY validator field the current client sends, not just the one a
// splice function happens to know about — a backend that misses one field
// rejects the whole stickyNotes:add and Drop Note silently dies. When a new
// optional note field ships, ADD A SPLICE FOR IT HERE and chain it below.
const SCOPE_ARG_LINE = "    scope: v.optional(v.union(v.literal('page'), v.literal('site'))),";
function spliceScope(src) {
  if (/\bscope:/.test(src)) return src; // already there
  const lines = src.split('\n');
  let touched = false;
  for (let i = 0; i < lines.length; i++) {
    if (ANCHOR_SELECTOR_RE.test(lines[i])) {
      lines.splice(i + 1, 0, SCOPE_ARG_LINE);
      i++;
      touched = true;
    }
  }
  return touched ? lines.join('\n') : src;
}

/** All splices a locally-modified copy needs, chained. Null = unsafe. */
function spliceAllIntoStickyNotes(src) {
  const af = spliceAFIntoStickyNotes(src);
  if (af === null) return null;
  return spliceScope(af);
}

function spliceAllIntoSchema(src) {
  const af = spliceAFIntoSchema(src);
  if (af === null) return null;
  return spliceScope(af);
}

function readEnvDeployment(dir) {
  for (const f of ['.env.local', '.env']) {
    const p = path.join(dir, f);
    if (!fs.existsSync(p)) continue;
    const txt = fs.readFileSync(p, 'utf8');
    const dep = txt.match(/^CONVEX_DEPLOYMENT=([^\s#]+)/m)?.[1] || null;
    const urlSlug =
      txt.match(/^(?:VITE_CONVEX_URL|NEXT_PUBLIC_CONVEX_URL)=https:\/\/([a-z0-9-]+)\.convex\.cloud/m)?.[1] ||
      null;
    if (dep || urlSlug) return { dep, urlSlug };
  }
  return { dep: null, urlSlug: null };
}

const depSlug = (dep) => dep.replace(/^(dev|prod):/, '');

function convexFunctionFiles(dir) {
  try {
    return fs
      .readdirSync(path.join(dir, 'convex'))
      .filter((f) => f.endsWith('.ts') && f !== 'tsconfig.json');
  } catch {
    return [];
  }
}

function runPush(dir, envValue, { prod = false } = {}) {
  const cmd = prod ? 'npx convex deploy --yes' : 'npx convex dev --once';
  try {
    const out = execSync(cmd, {
      cwd: dir,
      encoding: 'utf8',
      timeout: 5 * 60 * 1000,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, CI: '1', ...(prod ? {} : { CONVEX_DEPLOYMENT: envValue }) },
    });
    return { ok: true, out };
  } catch (e) {
    const head = [e.stdout, e.stderr, e.message]
      .filter(Boolean)
      .join('\n')
      .split('\n')
      .filter(Boolean)
      .slice(0, 12)
      .join(' | ');
    return { ok: false, out: head };
  }
}

function convexSync() {
  const extraSkips = skipArg ? skipArg.slice('--skip='.length).split(',') : [];
  const templates = fs
    .readdirSync(TEMPLATES_DIR)
    .filter((f) => f.endsWith('.ts'))
    .sort();

  const consumers = findConsumers();
  const rows = []; // per-consumer report rows

  for (const [dir] of consumers) {
    const name = path.basename(dir);
    const row = {
      dir,
      copied: [],
      spliced: [],
      current: [],
      leftAlone: [],
      deployment: null,
      push: 'n/a',
    };
    rows.push(row);

    const skipReason = CONVEX_SKIP[name] || (extraSkips.includes(name) ? '--skip' : null);
    if (skipReason) {
      row.push = `SKIPPED (${skipReason})`;
      continue;
    }
    if (!fs.existsSync(path.join(dir, 'convex', 'stickyNotes.ts'))) {
      row.push = 'SKIPPED (no convex/stickyNotes.ts)';
      continue;
    }

    for (const f of templates) {
      const dest = path.join(dir, 'convex', f);
      if (!fs.existsSync(dest)) continue; // never add brand-new modules
      const templateSrc = fs.readFileSync(path.join(TEMPLATES_DIR, f), 'utf8');
      const consumerSrc = fs.readFileSync(dest, 'utf8');
      const cls = classifyTemplateCopy(templateSrc, consumerSrc);
      if (cls === 'current') {
        row.current.push(f);
      } else if (cls === 'stale') {
        if (!dryRun) fs.writeFileSync(dest, templateSrc);
        row.copied.push(f);
      } else {
        // locally modified — only the two anchor-fingerprint files get a
        // surgical splice; everything else is left for a human
        const splice =
          f === 'multiplayerSchema.ts'
            ? spliceAllIntoSchema(consumerSrc)
            : f === 'stickyNotes.ts'
              ? spliceAllIntoStickyNotes(consumerSrc)
              : null;
        if (splice === consumerSrc) {
          row.current.push(`${f} (modified, already has all spliced fields)`);
        } else if (splice) {
          if (!dryRun) fs.writeFileSync(dest, splice);
          row.spliced.push(f);
        } else {
          row.leftAlone.push(f);
        }
      }
    }

    row.env = readEnvDeployment(dir);
    row.deployment = row.env.dep || row.env.urlSlug || null;
    if (!row.deployment) row.push = 'no deployment found in .env(.local)';
  }

  // Group pushable consumers by primary deployment slug; push ONCE per slug
  // from the dir whose convex/ file set covers every sibling's.
  const bySlug = new Map();
  for (const row of rows) {
    if (!row.deployment || row.push !== 'n/a') continue;
    const slug = depSlug(row.deployment);
    if (!bySlug.has(slug)) bySlug.set(slug, []);
    bySlug.get(slug).push(row);
  }

  for (const [slug, group] of bySlug) {
    const withSets = group.map((row) => ({ row, files: new Set(convexFunctionFiles(row.dir)) }));
    const pusher =
      withSets.find(({ files }) =>
        withSets.every(({ files: other }) => [...other].every((f) => files.has(f))),
      ) || withSets.sort((a, b) => b.files.size - a.files.size)[0];
    if (group.length > 1 && !withSets.every(({ files }) => [...files].every((f) => pusher.files.has(f)))) {
      console.log(`⚠ ${slug}: no consumer dir is a superset — pushing from ${pusher.row.dir} (largest)`);
    }

    if (dryRun) {
      for (const row of group) row.push = `dry-run (would push ${slug} from ${path.basename(pusher.row.dir)})`;
      continue;
    }
    console.log(`• pushing ${slug} from ${pusher.row.dir} …`);
    const res = runPush(pusher.row.dir, pusher.row.deployment);
    for (const row of group) {
      row.push = res.ok
        ? `ok (${slug}${row === pusher.row ? '' : ` via ${path.basename(pusher.row.dir)}`})`
        : `FAILED (${slug}): ${res.out}`;
    }

    // A dir whose env names a dev deployment AND a different URL slug serves
    // the live site from that other (prod) deployment — push it too.
    for (const row of group) {
      const { dep, urlSlug } = row.env;
      if (!dep || !urlSlug || depSlug(dep) === urlSlug) continue;
      console.log(`• pushing prod ${urlSlug} via \`convex deploy\` from ${row.dir} …`);
      const prodRes = runPush(row.dir, dep, { prod: true });
      row.push += prodRes.ok ? ` + prod ${urlSlug} ok` : ` + prod ${urlSlug} FAILED: ${prodRes.out}`;
    }
  }

  console.log(`\n═══ convex template sync report${dryRun ? ' (dry-run)' : ''} ═══`);
  for (const row of rows) {
    console.log(`\n${row.dir}`);
    console.log(`    deployment: ${row.deployment || '—'}`);
    if (row.copied.length) console.log(`    copied:     ${row.copied.join(', ')}`);
    if (row.spliced.length) console.log(`    spliced AF: ${row.spliced.join(', ')}`);
    if (row.current.length) console.log(`    current:    ${row.current.join(', ')}`);
    if (row.leftAlone.length) console.log(`    LEFT ALONE (local mods, needs human): ${row.leftAlone.join(', ')}`);
    console.log(`    push:       ${row.push}`);
  }
}

if (doConvex) {
  convexSync();
  // Record what was synced so publish-manifest's release-train guard knows
  // the fleet's backends match these templates (see cli/publish-manifest.js).
  if (!dryRun) {
    try {
      const crypto = await import('crypto');
      const h = crypto.createHash('sha256');
      const walk = (d) => {
        for (const f of fs.readdirSync(d).sort()) {
          const p = path.join(d, f);
          if (fs.statSync(p).isDirectory()) walk(p);
          else if (f.endsWith('.ts')) h.update(f).update(fs.readFileSync(p));
        }
      };
      walk(TEMPLATES_DIR);
      fs.writeFileSync(path.join(root, 'cli', '.templates-synced-hash'), h.digest('hex') + '\n');
    } catch (e) {
      console.error('warn: could not write .templates-synced-hash:', e?.message);
    }
  }
  process.exit(0);
}

const tarball = repack();
const version = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8')).version;
console.log(`• packed ${path.basename(tarball)} (v${version})\n`);

const consumers = findConsumers();
const synced = [];
const gitMain = [];
const skipped = [];

for (const [dir, spec] of consumers) {
  const name = path.basename(dir);
  if (spec.startsWith('file:')) {
    // Locate the vendor tarball path from the spec.
    const rel = spec.replace(/^file:/, '');
    const dest = path.resolve(dir, rel);
    try {
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(tarball, dest);
      fs.rmSync(path.join(dir, 'package-lock.json'), { force: true });
      fs.rmSync(path.join(dir, 'node_modules', '@quexopa'), { recursive: true, force: true });
      fs.rmSync(path.join(dir, 'node_modules', '.vite'), { recursive: true, force: true });
      if (doInstall) {
        execSync('npm install', { cwd: dir, stdio: 'ignore' });
      }
      synced.push(name);
    } catch (e) {
      skipped.push(`${name} (${e.message})`);
    }
  } else if (spec.includes('github.com') || spec.includes('git+')) {
    gitMain.push(name); // auto-updates on next deploy (pulls #main)
  } else {
    skipped.push(`${name} (spec: ${spec})`);
  }
}

console.log(`✓ synced ${synced.length} file:-tarball consumer(s) to v${version}:`);
synced.forEach((n) => console.log(`    ${n}`));
if (gitMain.length) {
  console.log(`\n↻ ${gitMain.length} git#main consumer(s) auto-update on redeploy:`);
  gitMain.forEach((n) => console.log(`    ${n}`));
}
if (skipped.length) {
  console.log(`\n⚠ skipped:`);
  skipped.forEach((n) => console.log(`    ${n}`));
}
console.log(`\nNext: redeploy the listed projects WITH --force:  npx vercel --prod --force`);
console.log(`(--force is REQUIRED: the vendored tarball keeps the same filename, so Vercel's`);
console.log(` build cache can restore an old node_modules and ship stale styling otherwise.)`);
