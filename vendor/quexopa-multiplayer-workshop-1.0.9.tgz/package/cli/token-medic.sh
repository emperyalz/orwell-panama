#!/bin/zsh
# =============================================================================
# mw-token-medic — keeps the fleet's "Update now" working.
#
# WHY: the update endpoints (multiplayer-dashboard-alpha /api/redeploy +
# /api/update-origin, and the merged Vercel DashBoard /api/mw/* and its main
# projects page) authenticate to the Vercel API with a copy of the CLI's
# access token in the projects' VERCEL_TOKEN env. Vercel CLI v50 access
# tokens live ~8 HOURS (auth.json: token + refreshToken + expiresAt), so the
# stored copy dies three times a day. Vercel forbids minting permanent tokens
# via the API from CLI credentials; until Eric creates one in the web
# dashboard (Account Settings → Tokens; then run once with MW_TOKEN=<value>)
# this medic:
#   1. probes the live endpoint hourly (bogus project = no build side-effect)
#   2. PROACTIVELY rotates when the installed token is within 2h of expiry
#      (zero-downtime: the old token stays valid until its expiresAt)
#   3. on any rotation, first runs `vercel whoami` to force the CLI to
#      refresh its access token via the refreshToken — without this, a dead
#      CLI session leaves the medic with nothing valid to install
#
# Runs via launchd (io.quexopa.mw-token-medic). Idempotent.
# Log: ~/.claude/logs/mw-token-medic.log   State: .token-medic-state (expiresAt)
# =============================================================================
set -u
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin"
# vercel is installed via nvm, invisible to launchd's bare PATH
for d in "$HOME/.nvm/versions/node"/*/bin(N); do
  [ -x "$d/vercel" ] && PATH="$d:$PATH"
done

LOG="$HOME/.claude/logs/mw-token-medic.log"
STATE="$HOME/multiplayer-workshop/cli/.token-medic-state"
AUTH_JSON="$HOME/Library/Application Support/com.vercel.cli/auth.json"
mkdir -p "$(dirname "$LOG")"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }

STANDALONE_DIR="$HOME/multiplayer-workshop/cloud/dashboard"
MERGED_DIR="$HOME/Vercel DashBoard"
PROBE_URL="https://multiplayer-dashboard-alpha.vercel.app/api/redeploy"
PROACTIVE_MARGIN=7200   # rotate when installed token has <2h left

# --- decide whether we need to rotate --------------------------------------
need_rotate=""
probe=$(curl -s -m 20 -X POST "$PROBE_URL" -H 'content-type: application/json' \
  -d '{"project":"mw-token-medic-probe-nonexistent"}')
if echo "$probe" | grep -qiE 'not authorized|re-authenticating|forbidden|invalid token'; then
  need_rotate="dead"
  log "stale token detected: $probe"
else
  # healthy — but rotate early if the installed token is about to expire
  installed_exp=$(cat "$STATE" 2>/dev/null || echo 0)
  now=$(date +%s)
  if [ "$installed_exp" -gt 0 ] && [ $((installed_exp - now)) -lt "$PROACTIVE_MARGIN" ]; then
    need_rotate="expiring"
    log "proactive rotation: installed token expires in $(( (installed_exp - now) / 60 )) min"
  fi
fi
[ -z "$need_rotate" ] && exit 0

if ! command -v vercel >/dev/null; then
  log "FATAL: vercel not on PATH — cannot rotate"
  exit 1
fi

# --- fresh credential -------------------------------------------------------
# MW_TOKEN override (permanent token) else refresh + read the CLI token.
TOKEN="${MW_TOKEN:-}"
TOKEN_EXP=4102444800   # permanent token: park expiry in 2100
if [ -z "$TOKEN" ]; then
  # `vercel whoami` only refreshes an EXPIRED token — a token with 10 minutes
  # left is kept as-is, and installing it means dying again immediately
  # (observed 2026-07-29). So: whoami first (revives a fully-dead session via
  # its refreshToken), then if the token has <3h of life, FORCE-refresh via
  # the CLI's own OAuth refresh grant (cli/refresh-vercel-token.py — also
  # rotates auth.json so the CLI session stays valid).
  vercel whoami >/dev/null 2>>"$LOG" || log "WARN: vercel whoami failed (continuing)"
  TOKEN_EXP=$(python3 -c "import json;print(int(json.load(open('$AUTH_JSON')).get('expiresAt',0)))" 2>>"$LOG")
  now=$(date +%s)
  if [ "${TOKEN_EXP:-0}" -lt $((now + 10800)) ]; then
    log "token has <3h left (exp $TOKEN_EXP) — force-refreshing via OAuth grant"
    if TOKEN=$(python3 "$HOME/multiplayer-workshop/cli/refresh-vercel-token.py" 2>>"$LOG"); then
      TOKEN_EXP=$(python3 -c "import json;print(int(json.load(open('$AUTH_JSON')).get('expiresAt',0)))" 2>>"$LOG")
    else
      log "WARN: force-refresh failed — falling back to stored token"
      TOKEN=""
    fi
  fi
  [ -z "$TOKEN" ] && TOKEN=$(python3 -c "import json;print(json.load(open('$AUTH_JSON'))['token'])" 2>>"$LOG")
fi
if [ -z "$TOKEN" ]; then log "FATAL: no token available"; exit 1; fi

# Sanity: the fresh token must actually work before we install it.
if ! curl -s -m 20 "https://api.vercel.com/v2/user" -H "Authorization: Bearer $TOKEN" | grep -q '"user"'; then
  log "FATAL: fresh token failed v2/user check even after refresh — CLI session is dead; needs 'vercel login' or MW_TOKEN"
  exit 1
fi

rotate() {
  local dir="$1"
  cd "$dir" || { log "FATAL: missing dir $dir"; return 1; }
  vercel env rm VERCEL_TOKEN production --yes >>"$LOG" 2>&1
  printf '%s' "$TOKEN" | vercel env add VERCEL_TOKEN production >>"$LOG" 2>&1
  if vercel --prod --force >>"$LOG" 2>&1; then
    log "rotated + redeployed: $dir"
  else
    log "ERROR: redeploy failed in $dir"
    return 1
  fi
}

fail=0
rotate "$STANDALONE_DIR" || fail=1
rotate "$MERGED_DIR" || fail=1
echo "$TOKEN_EXP" > "$STATE"

# --- verify heal (builds take a bit; poll up to 5 min) ----------------------
for i in $(seq 1 15); do
  sleep 20
  probe=$(curl -s -m 20 -X POST "$PROBE_URL" -H 'content-type: application/json' \
    -d '{"project":"mw-token-medic-probe-nonexistent"}')
  if ! echo "$probe" | grep -qiE 'not authorized|re-authenticating|forbidden|invalid token'; then
    log "HEALED (rotate reason: $need_rotate): $probe"
    exit $fail
  fi
done
log "WARN: still unhealthy after rotation: $probe"
exit 1
