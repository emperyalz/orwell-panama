// =============================================================================
// MULTIPLAYER WORKSHOP — Image-gen WRITER (V8 mutation)
// =============================================================================
// V8-side mutation paired with `imageGenAction.ts` (node). Patches the slide
// once the action has stored the generated image.
// =============================================================================

import { internalMutation } from './_generated/server';
import { v } from 'convex/values';

export const applyGeneratedImage = internalMutation({
  args: {
    slideId: v.id('slides'),
    storageId: v.id('_storage'),
    prompt: v.string(),
  },
  handler: async (ctx, { slideId, storageId, prompt }) => {
    await ctx.db.patch(slideId, {
      mediaStorageId: storageId,
      mediaType: 'image',
      updatedAt: Date.now(),
      // Seed the autoCaption with the prompt so the user has something
      // editable. The vision-caption flow can overwrite this later if the
      // user prefers automated descriptions.
      autoCaption: `Generated from: ${prompt.slice(0, 280)}`,
    });
  },
});
