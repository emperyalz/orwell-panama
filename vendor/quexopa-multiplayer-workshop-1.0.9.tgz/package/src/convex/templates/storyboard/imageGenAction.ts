'use node';
// =============================================================================
// MULTIPLAYER WORKSHOP — Slide image generation (Gemini 2.5 Flash Image)
// =============================================================================
// "Nano banana" — Google's Gemini 2.5 Flash Image model. Same `GEMINI_API_KEY`
// as visionCaptionAction, just a different model endpoint.
//
// Required env var on the Convex deployment:
//   GEMINI_API_KEY  — get from https://aistudio.google.com/apikey
//
// Falls back gracefully when the key isn't set: the action returns a soft
// error rather than throwing, so the UI can render a "set GEMINI_API_KEY"
// hint without crashing the slide.
// =============================================================================

import { action } from './_generated/server';
import { internal } from './_generated/api';
import { v } from 'convex/values';

declare const process: { env: Record<string, string | undefined> };
declare const Buffer: {
  from(input: ArrayBuffer | Uint8Array | string, encoding?: string): {
    toString(encoding: string): string;
    buffer: ArrayBuffer;
    byteOffset: number;
    byteLength: number;
  };
};

// Default model. Swap by passing `model` arg or by deploying a new template
// override with a different model string.
const DEFAULT_MODEL = 'gemini-2.5-flash-image-preview';

function endpointFor(model: string) {
  return `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
}

type GeminiPart = {
  text?: string;
  inlineData?: { mimeType: string; data: string };
};

async function callGeminiImageGen(
  apiKey: string,
  prompt: string,
  model: string,
): Promise<{ data: string; mimeType: string }> {
  const body = {
    contents: [
      {
        role: 'user',
        parts: [{ text: prompt }],
      },
    ],
    generationConfig: {
      responseModalities: ['IMAGE', 'TEXT'],
    },
  };
  const res = await fetch(`${endpointFor(model)}?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gemini image gen ${res.status}: ${errText.slice(0, 600)}`);
  }
  const json = (await res.json()) as any;
  const parts: GeminiPart[] = json?.candidates?.[0]?.content?.parts || [];
  const imagePart = parts.find((p) => p.inlineData?.data);
  if (!imagePart?.inlineData) {
    throw new Error('Gemini response contained no image data');
  }
  return {
    data: imagePart.inlineData.data,
    mimeType: imagePart.inlineData.mimeType || 'image/png',
  };
}

// =============================================================================
// PUBLIC ACTION — generate an image, store it, and patch the slide.
// =============================================================================
export const generateForSlide = action({
  args: {
    slideId: v.id('slides'),
    prompt: v.string(),
    model: v.optional(v.string()),
  },
  handler: async (ctx, { slideId, prompt, model }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return {
        ok: false as const,
        reason: 'no_api_key' as const,
        message: 'Set GEMINI_API_KEY on the Convex deployment to enable image generation.',
      };
    }
    if (!prompt || prompt.trim().length === 0) {
      return { ok: false as const, reason: 'empty_prompt' as const };
    }
    try {
      const { data, mimeType } = await callGeminiImageGen(
        apiKey,
        prompt,
        model || DEFAULT_MODEL,
      );
      const buf = Buffer.from(data, 'base64');
      const blob = new Blob([new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength)], {
        type: mimeType,
      });
      const storageId = await ctx.storage.store(blob);
      await ctx.runMutation(internal.imageGen.applyGeneratedImage, {
        slideId,
        storageId,
        prompt,
      });
      return { ok: true as const, storageId };
    } catch (e: any) {
      return {
        ok: false as const,
        reason: 'api_error' as const,
        message: e?.message || String(e),
      };
    }
  },
});
