// =============================================================================
// MULTIPLAYER WORKSHOP — Slide-scoped reference materials (one-off mood board)
// =============================================================================
// Copy to your `convex/slideReferences.ts`.
//
// These are distinct from `styleBibleEntities` — slide references are one-off
// mood-board uploads tied to a single slide, with a vision auto-caption and
// a free-text "what to extract" note.
// =============================================================================

import { mutation, query } from './_generated/server';
import { v } from 'convex/values';

export const list = query({
  args: { slideId: v.id('slides') },
  handler: async (ctx, { slideId }) => {
    return await ctx.db
      .query('slideReferences')
      .withIndex('by_slide', (q) => q.eq('slideId', slideId))
      .order('asc')
      .collect();
  },
});

// Bulk-fetch every reference for every slide in a storyboard. Used by the
// export panel to build CSV/JSON without N round-trips.
export const listForStoryboard = query({
  args: { storyboardId: v.id('storyboards') },
  handler: async (ctx, { storyboardId }) => {
    const slides = await ctx.db
      .query('slides')
      .withIndex('by_storyboard', (q) => q.eq('storyboardId', storyboardId))
      .collect();
    const slideIdSet = new Set(slides.map((s) => s._id));
    const all: any[] = [];
    for (const slide of slides) {
      const refs = await ctx.db
        .query('slideReferences')
        .withIndex('by_slide', (q) => q.eq('slideId', slide._id))
        .collect();
      for (const r of refs) all.push(r);
    }
    return all;
  },
});

export const add = mutation({
  args: {
    slideId: v.id('slides'),
    storageId: v.id('_storage'),
    mediaType: v.union(v.literal('image'), v.literal('video')),
    autoCaption: v.optional(v.string()),
    userExtractNote: v.optional(v.string()),
    createdBy: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert('slideReferences', {
      slideId: args.slideId,
      storageId: args.storageId,
      mediaType: args.mediaType,
      autoCaption: args.autoCaption,
      userExtractNote: args.userExtractNote,
      createdBy: args.createdBy,
      createdAt: Date.now(),
    });
  },
});

export const update = mutation({
  args: {
    id: v.id('slideReferences'),
    autoCaption: v.optional(v.string()),
    userExtractNote: v.optional(v.string()),
  },
  handler: async (ctx, { id, ...patch }) => {
    const cleaned: Record<string, unknown> = {};
    for (const [k, val] of Object.entries(patch)) {
      if (val !== undefined) cleaned[k] = val;
    }
    if (Object.keys(cleaned).length === 0) return;
    await ctx.db.patch(id, cleaned);
  },
});

export const remove = mutation({
  args: { id: v.id('slideReferences') },
  handler: async (ctx, { id }) => {
    await ctx.db.delete(id);
  },
});
