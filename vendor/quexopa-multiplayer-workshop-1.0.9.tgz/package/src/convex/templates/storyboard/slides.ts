// =============================================================================
// MULTIPLAYER WORKSHOP — Slide CRUD + drag-reorder + cross-references
// =============================================================================
// Copy to your `convex/slides.ts`.
//
// Drag-reorder model: each slide stores a fractional `orderKey` (lexicographic
// string). Moving a slide between A and B is a SINGLE-row write — no neighbor
// renumbering, race-free under multiplayer. See `lib/orderKey.ts` for the
// midpoint helper used client-side; the mutation just trusts what's sent.
// =============================================================================

import { mutation, query } from './_generated/server';
import { v } from 'convex/values';

const referenceValidator = v.object({
  slideId: v.id('slides'),
  hint: v.string(),
});

export const list = query({
  args: { storyboardId: v.id('storyboards') },
  handler: async (ctx, { storyboardId }) => {
    return await ctx.db
      .query('slides')
      .withIndex('by_storyboard', (q) => q.eq('storyboardId', storyboardId))
      .order('asc')
      .collect();
  },
});

export const get = query({
  args: { id: v.id('slides') },
  handler: async (ctx, { id }) => ctx.db.get(id),
});

export const add = mutation({
  args: {
    storyboardId: v.id('storyboards'),
    orderKey: v.string(),
    mediaStorageId: v.optional(v.id('_storage')),
    mediaType: v.union(v.literal('image'), v.literal('video'), v.literal('empty')),
    durationMs: v.optional(v.number()),
    playMode: v.optional(v.union(v.literal('inline'), v.literal('hold'))),
    shotDescription: v.optional(v.string()),
    sceneBreakBefore: v.optional(v.string()),
    createdBy: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    return await ctx.db.insert('slides', {
      storyboardId: args.storyboardId,
      orderKey: args.orderKey,
      mediaStorageId: args.mediaStorageId,
      mediaType: args.mediaType,
      durationMs: args.durationMs ?? 1500,
      playMode: args.playMode ?? 'inline',
      shotDescription: args.shotDescription ?? '',
      sceneBreakBefore: args.sceneBreakBefore,
      createdBy: args.createdBy,
      createdAt: now,
      updatedAt: now,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id('slides'),
    orderKey: v.optional(v.string()),
    mediaStorageId: v.optional(v.id('_storage')),
    mediaType: v.optional(v.union(v.literal('image'), v.literal('video'), v.literal('empty'))),
    durationMs: v.optional(v.number()),
    playMode: v.optional(v.union(v.literal('inline'), v.literal('hold'))),
    shotDescription: v.optional(v.string()),
    sceneBreakBefore: v.optional(v.string()),
    cameraAngle: v.optional(v.string()),
    shotSize: v.optional(v.string()),
    cameraMovement: v.optional(v.string()),
    lens: v.optional(v.string()),
    autoCaption: v.optional(v.string()),
    appliedEntityIds: v.optional(v.array(v.id('styleBibleEntities'))),
  },
  handler: async (ctx, { id, ...patch }) => {
    const cleaned: Record<string, unknown> = { updatedAt: Date.now() };
    for (const [k, val] of Object.entries(patch)) {
      if (val !== undefined) cleaned[k] = val;
    }
    await ctx.db.patch(id, cleaned);
  },
});

// Bulk-update many slides at once. Used by the multi-select bulk-edit panel
// to apply duration / playMode / camera metadata across a selection.
export const bulkUpdate = mutation({
  args: {
    ids: v.array(v.id('slides')),
    durationMs: v.optional(v.number()),
    playMode: v.optional(v.union(v.literal('inline'), v.literal('hold'))),
    cameraAngle: v.optional(v.string()),
    shotSize: v.optional(v.string()),
    cameraMovement: v.optional(v.string()),
    lens: v.optional(v.string()),
  },
  handler: async (ctx, { ids, ...patch }) => {
    const cleaned: Record<string, unknown> = { updatedAt: Date.now() };
    for (const [k, val] of Object.entries(patch)) {
      if (val !== undefined) cleaned[k] = val;
    }
    if (Object.keys(cleaned).length === 1) return; // only updatedAt — no-op
    for (const id of ids) {
      await ctx.db.patch(id, cleaned);
    }
  },
});

// Move a slide to a new orderKey. Single-row write.
export const reorder = mutation({
  args: { id: v.id('slides'), orderKey: v.string() },
  handler: async (ctx, { id, orderKey }) => {
    await ctx.db.patch(id, { orderKey, updatedAt: Date.now() });
  },
});

export const remove = mutation({
  args: { id: v.id('slides') },
  handler: async (ctx, { id }) => {
    // Cascade: delete the slide's references first
    const refs = await ctx.db
      .query('slideReferences')
      .withIndex('by_slide', (q) => q.eq('slideId', id))
      .collect();
    for (const r of refs) await ctx.db.delete(r._id);
    // Strip any cross-slide refs pointing to this slide from sibling slides.
    const slide = await ctx.db.get(id);
    if (slide) {
      const siblings = await ctx.db
        .query('slides')
        .withIndex('by_storyboard', (q) => q.eq('storyboardId', slide.storyboardId))
        .collect();
      for (const s of siblings) {
        if (!s.references) continue;
        const filtered = s.references.filter((r) => r.slideId !== id);
        if (filtered.length !== s.references.length) {
          await ctx.db.patch(s._id, { references: filtered, updatedAt: Date.now() });
        }
      }
    }
    await ctx.db.delete(id);
  },
});

// Apply / remove a style-bible entity to a slide.
export const setAppliedEntities = mutation({
  args: {
    id: v.id('slides'),
    entityIds: v.array(v.id('styleBibleEntities')),
  },
  handler: async (ctx, { id, entityIds }) => {
    await ctx.db.patch(id, { appliedEntityIds: entityIds, updatedAt: Date.now() });
  },
});

// Cross-slide references — bulk replace.
export const setReferences = mutation({
  args: {
    id: v.id('slides'),
    references: v.array(referenceValidator),
  },
  handler: async (ctx, { id, references }) => {
    await ctx.db.patch(id, { references, updatedAt: Date.now() });
  },
});
