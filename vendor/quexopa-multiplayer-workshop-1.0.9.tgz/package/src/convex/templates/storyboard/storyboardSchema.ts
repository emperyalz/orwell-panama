// =============================================================================
// MULTIPLAYER WORKSHOP — Storyboard tables (opt-in)
// =============================================================================
//
// This is an OPTIONAL schema fragment. Spread it into your `convex/schema.ts`
// alongside `multiplayerTables` if your project uses the storyboarding feature.
// Hosts that don't use storyboards can ignore this file entirely — no other
// part of the package depends on these tables.
//
//   import { defineSchema } from 'convex/server';
//   import { multiplayerTables } from './multiplayerSchema';
//   import { storyboardTables } from './storyboardSchema';
//
//   export default defineSchema({
//     ...multiplayerTables,
//     ...storyboardTables,
//     // ...your own tables
//   });
//
// =============================================================================

import { defineTable } from 'convex/server';
import { v } from 'convex/values';

// Camera + shot vocabulary the prompt template engine knows how to interpolate.
// Stored as plain strings — the controlled vocab is enforced in the UI, not at
// the schema layer, so future expansions don't require a migration.
const cameraAngleValidator = v.optional(v.string()); // 'low' | 'high' | 'eye' | 'dutch' | 'overhead' | 'ots'
const shotSizeValidator = v.optional(v.string()); // 'extreme-wide' | 'wide' | 'medium' | 'close-up' | 'extreme-close-up'
const cameraMovementValidator = v.optional(v.string()); // 'static' | 'pan' | 'tilt' | 'dolly' | 'truck' | 'orbit' | 'crane' | 'zoom'
const lensValidator = v.optional(v.string()); // free text — '14mm' | '35mm' | '50mm' | '85mm' | etc

export const storyboardTables = {
  // ──────────────────────────────────────────────────────────────────────────
  // storyboards: one row per board, scoped to a multiplayer sessionId.
  // ──────────────────────────────────────────────────────────────────────────
  storyboards: defineTable({
    sessionId: v.string(),
    title: v.string(),
    description: v.optional(v.string()),
    // Default video LLM the prompt panel renders for. Free text so new models
    // can be added without a schema migration.
    defaultModel: v.optional(v.string()), // 'runway' | 'sora' | 'veo' | 'kling' | 'seedance' | 'higgsfield' | 'generic'
    // Cold-start origin. v1 ships 'blank' | 'image' | 'video'.
    origin: v.optional(v.string()),
    // Public read-link token. Anyone with the token can view the board and
    // leave anonymous comments. NULL = no share link issued.
    shareToken: v.optional(v.string()),
    shareTokenIssuedAt: v.optional(v.number()),
    // Board-level status. v1 = 'editing'; v2 adds 'review' / 'sign-off' / 'final'.
    status: v.optional(v.string()),
    createdBy: v.string(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    .index('by_session', ['sessionId'])
    .index('by_share_token', ['shareToken']),

  // ──────────────────────────────────────────────────────────────────────────
  // slides: ordered children of a storyboard. Drag-reorder uses a fractional
  // `orderKey` so a single moved slide is a single-row write — no neighbor
  // renumbering, race-free under multiplayer.
  // ──────────────────────────────────────────────────────────────────────────
  slides: defineTable({
    storyboardId: v.id('storyboards'),
    // Lexicographic fractional index. See `lib/orderKey.ts` for helpers.
    orderKey: v.string(),
    // Optional scene break label that renders ABOVE this slide as a divider
    // row. Flat list with insertable scene markers (v1 model — no real
    // hierarchy yet).
    sceneBreakBefore: v.optional(v.string()),
    // Asset
    mediaStorageId: v.optional(v.id('_storage')),
    mediaType: v.union(v.literal('image'), v.literal('video'), v.literal('empty')),
    // Playback
    durationMs: v.number(), // default 1500
    // Per-slide playback decision: video plays inline for the duration, OR
    // first-frame holds for the duration. Image slides ignore this.
    playMode: v.optional(v.union(v.literal('inline'), v.literal('hold'))),
    // The user-authored shot description. Feeds the prompt template.
    shotDescription: v.string(),
    // Optional camera/shot metadata — controlled vocab in the UI, free string
    // here. Each one becomes a slot in the prompt template.
    cameraAngle: cameraAngleValidator,
    shotSize: shotSizeValidator,
    cameraMovement: cameraMovementValidator,
    lens: lensValidator,
    // Cross-slide references — array of slide IDs and a free-text hint that
    // gets inlined in the prompt (e.g. "same character as slide 3, turning left").
    references: v.optional(
      v.array(
        v.object({
          slideId: v.id('slides'),
          hint: v.string(),
        }),
      ),
    ),
    // Style-bible entities applied to this slide (subset of the board's bible —
    // not every slide needs every character).
    appliedEntityIds: v.optional(v.array(v.id('styleBibleEntities'))),
    // Vision-auto-caption populated when media is uploaded; user-editable.
    autoCaption: v.optional(v.string()),
    createdBy: v.string(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
    // Compound index gives us cheap ordered reads per board.
    .index('by_storyboard', ['storyboardId', 'orderKey']),

  // ──────────────────────────────────────────────────────────────────────────
  // styleBibleEntities: characters / environments / props / camera looks
  // defined at the board level. Reusable across slides.
  // ──────────────────────────────────────────────────────────────────────────
  styleBibleEntities: defineTable({
    storyboardId: v.id('storyboards'),
    type: v.union(
      v.literal('character'),
      v.literal('environment'),
      v.literal('prop'),
      v.literal('camera_look'),
    ),
    // Subtype within `type` — drives suggestion chips and (optionally) the
    // prompt template's framing of this entity. Free string so vocabularies
    // can grow without schema migrations.
    // - character: 'main' | 'costar' | 'supporting' | 'antagonist' | 'background' | 'creature'
    // - environment: 'exterior-natural' | 'exterior-urban' | 'interior-domestic' | ...
    // - prop: 'handheld' | 'furniture' | 'vehicle' | 'decoration' | 'key-prop'
    // - camera_look: 'cinematic' | 'doc' | 'hyperreal' | 'stylized' | 'music-video' | 'noir'
    subtype: v.optional(v.string()),
    name: v.string(),
    description: v.string(), // user-edited, often seeded by auto-caption
    // Reference images. First entry is the primary thumbnail.
    referenceStorageIds: v.optional(v.array(v.id('_storage'))),
    // Vision-auto-caption populated on first reference upload; user-editable.
    autoCaption: v.optional(v.string()),
    // Free-form attribute tags: { hairColor: 'black', wardrobe: 'red jacket', ... }
    // The prompt template can pull individual keys or a flattened summary.
    attributes: v.optional(v.record(v.string(), v.string())),
    createdBy: v.string(),
    createdAt: v.number(),
    updatedAt: v.number(),
  }).index('by_storyboard', ['storyboardId']),

  // ──────────────────────────────────────────────────────────────────────────
  // slideReferences: external mood-board uploads tied to a single slide.
  // Distinct from styleBibleEntities — these are one-off references, not
  // persistent entities.
  // ──────────────────────────────────────────────────────────────────────────
  slideReferences: defineTable({
    slideId: v.id('slides'),
    storageId: v.id('_storage'),
    mediaType: v.union(v.literal('image'), v.literal('video')),
    // Vision-generated, editable.
    autoCaption: v.optional(v.string()),
    // What the user wants to extract from this reference (e.g. "use this
    // lighting", "match this outfit"). Inlined into the slide's prompt.
    userExtractNote: v.optional(v.string()),
    createdBy: v.string(),
    createdAt: v.number(),
  }).index('by_slide', ['slideId']),

  // ──────────────────────────────────────────────────────────────────────────
  // promptTemplates: per-model rendering templates. Stored mustache-ish strings
  // with named slots. Defaults ship in `lib/promptTemplates.ts`; this table
  // lets a host override per-model or per-storyboard.
  // ──────────────────────────────────────────────────────────────────────────
  promptTemplates: defineTable({
    // null/undefined = global override (applies to all storyboards in the host)
    storyboardId: v.optional(v.id('storyboards')),
    model: v.string(), // 'runway' | 'sora' | 'veo' | 'kling' | 'seedance' | 'higgsfield' | 'generic'
    template: v.string(),
    updatedBy: v.string(),
    updatedAt: v.number(),
  })
    .index('by_model', ['model'])
    .index('by_storyboard_model', ['storyboardId', 'model']),
};
