// =============================================================================
// MULTIPLAYER WORKSHOP — Storyboard CRUD + share-link
// =============================================================================
// Copy to your `convex/storyboards.ts` (or run `npx multiplayer-workshop init
// --with-storyboards`).
// =============================================================================

import { mutation, query } from './_generated/server';
import { v } from 'convex/values';

export const getById = query({
  args: { id: v.id('storyboards') },
  handler: async (ctx, { id }) => {
    return await ctx.db.get(id);
  },
});

export const listForSession = query({
  args: { sessionId: v.string() },
  handler: async (ctx, { sessionId }) => {
    return await ctx.db
      .query('storyboards')
      .withIndex('by_session', (q) => q.eq('sessionId', sessionId))
      .order('desc')
      .collect();
  },
});

export const getByShareToken = query({
  args: { shareToken: v.string() },
  handler: async (ctx, { shareToken }) => {
    return await ctx.db
      .query('storyboards')
      .withIndex('by_share_token', (q) => q.eq('shareToken', shareToken))
      .first();
  },
});

export const create = mutation({
  args: {
    sessionId: v.string(),
    title: v.string(),
    description: v.optional(v.string()),
    defaultModel: v.optional(v.string()),
    origin: v.optional(v.string()),
    createdBy: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    return await ctx.db.insert('storyboards', {
      sessionId: args.sessionId,
      title: args.title,
      description: args.description,
      defaultModel: args.defaultModel ?? 'generic',
      origin: args.origin ?? 'blank',
      status: 'editing',
      createdBy: args.createdBy,
      createdAt: now,
      updatedAt: now,
    });
  },
});

export const updateMeta = mutation({
  args: {
    id: v.id('storyboards'),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    defaultModel: v.optional(v.string()),
    status: v.optional(v.string()),
  },
  handler: async (ctx, { id, ...patch }) => {
    const cleaned: Record<string, unknown> = { updatedAt: Date.now() };
    for (const [k, val] of Object.entries(patch)) {
      if (val !== undefined) cleaned[k] = val;
    }
    await ctx.db.patch(id, cleaned);
  },
});

export const remove = mutation({
  args: { id: v.id('storyboards') },
  handler: async (ctx, { id }) => {
    // Cascade: slides → references → entities → prompt overrides
    const slides = await ctx.db
      .query('slides')
      .withIndex('by_storyboard', (q) => q.eq('storyboardId', id))
      .collect();
    for (const s of slides) {
      const refs = await ctx.db
        .query('slideReferences')
        .withIndex('by_slide', (q) => q.eq('slideId', s._id))
        .collect();
      for (const r of refs) await ctx.db.delete(r._id);
      await ctx.db.delete(s._id);
    }
    const entities = await ctx.db
      .query('styleBibleEntities')
      .withIndex('by_storyboard', (q) => q.eq('storyboardId', id))
      .collect();
    for (const e of entities) await ctx.db.delete(e._id);
    const overrides = await ctx.db
      .query('promptTemplates')
      .withIndex('by_storyboard_model', (q) => q.eq('storyboardId', id))
      .collect();
    for (const o of overrides) await ctx.db.delete(o._id);
    await ctx.db.delete(id);
  },
});

// =============================================================================
// SHARE LINK
// =============================================================================
// Generates an opaque token. The host's public-read route checks this token
// and renders read-only with anonymous-comment access (handled by the existing
// StickyNotesProvider — anyone can leave a note, edit gating is the host's
// responsibility).

function randomToken(length = 24): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let s = '';
  for (let i = 0; i < length; i++) {
    s += chars[Math.floor(Math.random() * chars.length)];
  }
  return s;
}

export const issueShareToken = mutation({
  args: { id: v.id('storyboards') },
  handler: async (ctx, { id }) => {
    const board = await ctx.db.get(id);
    if (!board) throw new Error('Storyboard not found');
    if (board.shareToken) return board.shareToken;
    const token = randomToken(24);
    await ctx.db.patch(id, {
      shareToken: token,
      shareTokenIssuedAt: Date.now(),
      updatedAt: Date.now(),
    });
    return token;
  },
});

export const revokeShareToken = mutation({
  args: { id: v.id('storyboards') },
  handler: async (ctx, { id }) => {
    await ctx.db.patch(id, {
      shareToken: undefined,
      shareTokenIssuedAt: undefined,
      updatedAt: Date.now(),
    });
  },
});

// =============================================================================
// FORK / VERSIONING
// =============================================================================
// Snapshot the storyboard. Creates a new board (same sessionId) with all
// slides, style-bible entities, and slide references copied. Slide-IDs are
// remapped — `appliedEntityIds` and `references[].slideId` are rewritten so
// the copy is internally consistent.
//
// Pairs with the multiplayer-workshop version system: the host can also call
// `sessions:createVersion` to fork the entire session (and any storyboards
// under it would still need this fork to follow). We intentionally keep the
// two systems decoupled — sessions own the multiplayer state, storyboards own
// their own children.

export const fork = mutation({
  args: {
    sourceId: v.id('storyboards'),
    label: v.optional(v.string()),
    actor: v.string(),
  },
  handler: async (ctx, { sourceId, label, actor }) => {
    const source = await ctx.db.get(sourceId);
    if (!source) throw new Error('Source storyboard not found');
    const now = Date.now();
    const newBoard = await ctx.db.insert('storyboards', {
      sessionId: source.sessionId,
      title: label || `${source.title} (snapshot)`,
      description: source.description,
      defaultModel: source.defaultModel,
      origin: source.origin,
      status: 'editing',
      createdBy: actor,
      createdAt: now,
      updatedAt: now,
      // Don't carry the share token; new board gets its own.
    });

    // Copy entities first; remember old→new ID map for later remapping.
    const sourceEntities = await ctx.db
      .query('styleBibleEntities')
      .withIndex('by_storyboard', (q) => q.eq('storyboardId', sourceId))
      .collect();
    const entityIdMap = new Map<string, any>();
    for (const e of sourceEntities) {
      const newId = await ctx.db.insert('styleBibleEntities', {
        storyboardId: newBoard,
        type: e.type,
        name: e.name,
        description: e.description,
        referenceStorageIds: e.referenceStorageIds,
        autoCaption: e.autoCaption,
        attributes: e.attributes,
        createdBy: actor,
        createdAt: now,
        updatedAt: now,
      });
      entityIdMap.set(e._id, newId);
    }

    // Copy slides — first pass inserts without cross-refs / applied entities,
    // builds an old→new slide ID map. Second pass patches the cross-refs.
    const sourceSlides = await ctx.db
      .query('slides')
      .withIndex('by_storyboard', (q) => q.eq('storyboardId', sourceId))
      .order('asc')
      .collect();
    const slideIdMap = new Map<string, any>();
    for (const s of sourceSlides) {
      const newSlideId = await ctx.db.insert('slides', {
        storyboardId: newBoard,
        orderKey: s.orderKey,
        sceneBreakBefore: s.sceneBreakBefore,
        mediaStorageId: s.mediaStorageId,
        mediaType: s.mediaType,
        durationMs: s.durationMs,
        playMode: s.playMode,
        shotDescription: s.shotDescription,
        cameraAngle: s.cameraAngle,
        shotSize: s.shotSize,
        cameraMovement: s.cameraMovement,
        lens: s.lens,
        autoCaption: s.autoCaption,
        createdBy: actor,
        createdAt: now,
        updatedAt: now,
      });
      slideIdMap.set(s._id, newSlideId);
    }

    // Second pass: remap appliedEntityIds + references[].slideId.
    for (const s of sourceSlides) {
      const newSlideId = slideIdMap.get(s._id)!;
      const remappedEntities = (s.appliedEntityIds || [])
        .map((id) => entityIdMap.get(id))
        .filter(Boolean);
      const remappedRefs = (s.references || [])
        .map((r) => {
          const newTargetId = slideIdMap.get(r.slideId);
          return newTargetId ? { slideId: newTargetId, hint: r.hint } : null;
        })
        .filter(Boolean) as { slideId: any; hint: string }[];
      const patch: Record<string, unknown> = {};
      if (remappedEntities.length > 0) patch.appliedEntityIds = remappedEntities;
      if (remappedRefs.length > 0) patch.references = remappedRefs;
      if (Object.keys(patch).length > 0) {
        await ctx.db.patch(newSlideId, patch);
      }
    }

    // Copy slide references (mood-board uploads).
    for (const s of sourceSlides) {
      const newSlideId = slideIdMap.get(s._id)!;
      const refs = await ctx.db
        .query('slideReferences')
        .withIndex('by_slide', (q) => q.eq('slideId', s._id))
        .collect();
      for (const r of refs) {
        await ctx.db.insert('slideReferences', {
          slideId: newSlideId,
          storageId: r.storageId,
          mediaType: r.mediaType,
          autoCaption: r.autoCaption,
          userExtractNote: r.userExtractNote,
          createdBy: actor,
          createdAt: now,
        });
      }
    }

    return newBoard;
  },
});
