// =============================================================================
// MULTIPLAYER WORKSHOP — Style Bible (typed entities at the storyboard level)
// =============================================================================
// Copy to your `convex/styleBible.ts`.
//
// Entities (character / environment / prop / camera_look) are reusable across
// slides. A slide opts in to a subset via `appliedEntityIds`.
// =============================================================================

import { mutation, query } from './_generated/server';
import { v } from 'convex/values';

const entityTypeValidator = v.union(
  v.literal('character'),
  v.literal('environment'),
  v.literal('prop'),
  v.literal('camera_look'),
);

export const list = query({
  args: { storyboardId: v.id('storyboards') },
  handler: async (ctx, { storyboardId }) => {
    return await ctx.db
      .query('styleBibleEntities')
      .withIndex('by_storyboard', (q) => q.eq('storyboardId', storyboardId))
      .order('asc')
      .collect();
  },
});

export const get = query({
  args: { id: v.id('styleBibleEntities') },
  handler: async (ctx, { id }) => ctx.db.get(id),
});

export const add = mutation({
  args: {
    storyboardId: v.id('storyboards'),
    type: entityTypeValidator,
    subtype: v.optional(v.string()),
    name: v.string(),
    description: v.optional(v.string()),
    referenceStorageIds: v.optional(v.array(v.id('_storage'))),
    autoCaption: v.optional(v.string()),
    attributes: v.optional(v.record(v.string(), v.string())),
    createdBy: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    return await ctx.db.insert('styleBibleEntities', {
      storyboardId: args.storyboardId,
      type: args.type,
      subtype: args.subtype,
      name: args.name,
      description: args.description ?? '',
      referenceStorageIds: args.referenceStorageIds,
      autoCaption: args.autoCaption,
      attributes: args.attributes,
      createdBy: args.createdBy,
      createdAt: now,
      updatedAt: now,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id('styleBibleEntities'),
    name: v.optional(v.string()),
    subtype: v.optional(v.string()),
    description: v.optional(v.string()),
    autoCaption: v.optional(v.string()),
    attributes: v.optional(v.record(v.string(), v.string())),
  },
  handler: async (ctx, { id, ...patch }) => {
    const cleaned: Record<string, unknown> = { updatedAt: Date.now() };
    for (const [k, val] of Object.entries(patch)) {
      if (val !== undefined) cleaned[k] = val;
    }
    await ctx.db.patch(id, cleaned);
  },
});

export const addReferenceImage = mutation({
  args: {
    id: v.id('styleBibleEntities'),
    storageId: v.id('_storage'),
  },
  handler: async (ctx, { id, storageId }) => {
    const entity = await ctx.db.get(id);
    if (!entity) throw new Error('Entity not found');
    const existing = entity.referenceStorageIds || [];
    await ctx.db.patch(id, {
      referenceStorageIds: [...existing, storageId],
      updatedAt: Date.now(),
    });
  },
});

export const removeReferenceImage = mutation({
  args: {
    id: v.id('styleBibleEntities'),
    index: v.number(),
  },
  handler: async (ctx, { id, index }) => {
    const entity = await ctx.db.get(id);
    if (!entity) throw new Error('Entity not found');
    const existing = entity.referenceStorageIds || [];
    if (index < 0 || index >= existing.length) {
      throw new Error('Reference index out of range');
    }
    await ctx.db.patch(id, {
      referenceStorageIds: existing.filter((_, i) => i !== index),
      updatedAt: Date.now(),
    });
  },
});

export const remove = mutation({
  args: { id: v.id('styleBibleEntities') },
  handler: async (ctx, { id }) => {
    // Strip this entity from any slide's appliedEntityIds before deleting.
    const entity = await ctx.db.get(id);
    if (entity) {
      const slides = await ctx.db
        .query('slides')
        .withIndex('by_storyboard', (q) => q.eq('storyboardId', entity.storyboardId))
        .collect();
      for (const s of slides) {
        if (!s.appliedEntityIds) continue;
        const filtered = s.appliedEntityIds.filter((eid) => eid !== id);
        if (filtered.length !== s.appliedEntityIds.length) {
          await ctx.db.patch(s._id, {
            appliedEntityIds: filtered,
            updatedAt: Date.now(),
          });
        }
      }
    }
    await ctx.db.delete(id);
  },
});
