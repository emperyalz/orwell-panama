// =============================================================================
// MULTIPLAYER WORKSHOP — Vision caption WRITER (V8 mutation)
// =============================================================================
// Copy to your `convex/visionCaption.ts`. Pairs with `visionCaptionAction.ts`
// (node) — split per Gotcha #4: V8 mutations and node actions can't share a
// file.
// =============================================================================

import { internalMutation } from './_generated/server';
import { v } from 'convex/values';

export const writeCaption = internalMutation({
  args: {
    target: v.union(
      v.object({ kind: v.literal('slide'), slideId: v.id('slides') }),
      v.object({
        kind: v.literal('entity'),
        entityId: v.id('styleBibleEntities'),
      }),
      v.object({
        kind: v.literal('reference'),
        referenceId: v.id('slideReferences'),
      }),
    ),
    caption: v.string(),
  },
  handler: async (ctx, { target, caption }) => {
    const now = Date.now();
    if (target.kind === 'slide') {
      await ctx.db.patch(target.slideId, { autoCaption: caption, updatedAt: now });
    } else if (target.kind === 'entity') {
      await ctx.db.patch(target.entityId, { autoCaption: caption, updatedAt: now });
    } else {
      // slideReferences has no updatedAt field
      await ctx.db.patch(target.referenceId, { autoCaption: caption });
    }
  },
});
