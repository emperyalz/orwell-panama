'use node';
// =============================================================================
// MULTIPLAYER WORKSHOP — Vision caption action (Gemini 2.5 Flash)
// =============================================================================
// Copy to your `convex/visionCaptionAction.ts`. This is a NODE action — split
// from V8 mutations because it uses fetch + process.env (Gotcha #4 from the
// package's skill: V8 and node can't share a file).
//
// Pairs with `visionCaption.ts` (V8) which writes the caption back to the row.
//
// Required env var on the Convex deployment:
//   GEMINI_API_KEY  — same key used for Gemini ("nano banana") image gen.
//
// Set with: npx convex env set GEMINI_API_KEY=sk-...
//
// If the env var is missing, captioning silently no-ops — the slide / entity /
// reference still saves successfully and the user can fill the caption manually.
// =============================================================================

import { action } from './_generated/server';
import { internal } from './_generated/api';
import { v } from 'convex/values';

// Local ambient declarations — Convex's node runtime provides these at runtime,
// but the host's tsconfig may not include @types/node. Declaring them here
// keeps hosts from needing a node-types dev dep just for this file.
declare const process: { env: Record<string, string | undefined> };
declare const Buffer: {
  from(input: ArrayBuffer | Uint8Array): { toString(encoding: string): string };
};

const GEMINI_MODEL = 'gemini-2.5-flash';
const GEMINI_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

const SYSTEM_PROMPT = `You write concise, structured visual captions for a film/video storyboarding tool. Output ONLY a single JSON object with these keys (all strings, no markdown, no commentary):

  caption        — one sentence describing the subject and action (max 30 words)
  subjects       — comma-separated list of people/objects visible
  lighting       — short phrase ("warm tungsten side-light", "overcast diffuse", etc.)
  palette        — 3 dominant colors as comma-separated hex codes
  mood           — one or two adjectives ("tense", "playful melancholy")

Be specific and visual. No editorializing. If the image is unclear, return your best guess — don't refuse.`;

async function fetchAndEncodeImage(url: string): Promise<{ data: string; mimeType: string }> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch image: ${res.status}`);
  const mimeType = res.headers.get('content-type') || 'image/jpeg';
  const buf = await res.arrayBuffer();
  // Base64 — Convex node runtime has Buffer
  const data = Buffer.from(buf).toString('base64');
  return { data, mimeType };
}

async function callGemini(apiKey: string, imageData: string, mimeType: string): Promise<string> {
  const body = {
    contents: [
      {
        role: 'user',
        parts: [
          { text: SYSTEM_PROMPT },
          { inlineData: { mimeType, data: imageData } },
        ],
      },
    ],
    generationConfig: {
      temperature: 0.3,
      responseMimeType: 'application/json',
    },
  };
  const res = await fetch(`${GEMINI_ENDPOINT}?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gemini API error ${res.status}: ${errText.slice(0, 500)}`);
  }
  const json = (await res.json()) as any;
  const text = json?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error('Gemini returned no text');
  return text;
}

function flattenCaption(rawJson: string): string {
  try {
    const parsed = JSON.parse(rawJson);
    const parts = [
      parsed.caption,
      parsed.subjects && `Subjects: ${parsed.subjects}`,
      parsed.lighting && `Lighting: ${parsed.lighting}`,
      parsed.palette && `Palette: ${parsed.palette}`,
      parsed.mood && `Mood: ${parsed.mood}`,
    ].filter(Boolean);
    return parts.join('. ');
  } catch {
    return rawJson.trim().slice(0, 600);
  }
}

// =============================================================================
// PUBLIC ACTION — fire-and-forget from the client. Returns success status; the
// caller can ignore it. The caption gets written via a V8 mutation in the
// sibling `visionCaption.ts` file.
// =============================================================================
export const captionForStorageId = action({
  args: {
    storageId: v.id('_storage'),
    target: v.union(
      v.object({ kind: v.literal('slide'), slideId: v.id('slides') }),
      v.object({
        kind: v.literal('entity'),
        entityId: v.id('styleBibleEntities'),
      }),
      v.object({
        kind: v.literal('reference'),
        referenceId: v.id('slideReferences'),
      }),
    ),
  },
  handler: async (ctx, { storageId, target }) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return { ok: false, reason: 'no_api_key' as const };
    }
    const url = await ctx.storage.getUrl(storageId);
    if (!url) return { ok: false, reason: 'no_storage_url' as const };

    try {
      const { data, mimeType } = await fetchAndEncodeImage(url);
      const raw = await callGemini(apiKey, data, mimeType);
      const caption = flattenCaption(raw);
      await ctx.runMutation(internal.visionCaption.writeCaption, {
        target,
        caption,
      });
      return { ok: true, caption };
    } catch (e: any) {
      return { ok: false, reason: e?.message || String(e) };
    }
  },
});
